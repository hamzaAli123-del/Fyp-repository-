# Traffic Analysis and Monitoring System  

**Technical Project Report**

---

## Abstract

This report describes an end-to-end **traffic analysis system** built from commodity computer-vision tooling and web technologies. A **FastAPI** backend captures video (stream URL or local camera fallback), runs **YOLOv8–based vehicle detection**, associates detections across time with **IoU-based bipartite matching**, estimates **approximate speeds** from pixel motion and from **virtual reference lines**, and classifies scene-level congestion with **threshold rules**. A **Next.js** dashboard consumes REST and **MJPEG** endpoints to visualize annotated video, live metrics, charts, and optional **CSV / JSON exports**. The work is framed as an academic prototype suitable for coursework or demonstration—not as certified infrastructure for lawful speed enforcement or real-time traffic-actuated control without further engineering.

---

## 1. Introduction

Urban traffic generates visible patterns: vehicle density rises, spacing shrinks, and average motion drops when roads approach capacity. Agencies increasingly explore **camera-based analytics** alongside traditional sensors.

This project implements a unified pipeline—from **streaming video ingestion** through **deep-learning detection**, **online multi-object association**, simple **speed metrics**, rule-based **congestion labeling**, and a **modern web frontend**—so that operators can inspect both **spatial** overlays (bounding boxes, IDs, speeds drawn on frames) and **temporal** trends (polling-based time series).

**Distinction:** The delivered software does **not** interface with physical traffic controllers, roadside loops, or signal timing units. Outputs are explanatory and illustrative.

---

## 2. Background and motivation

Traditional monitoring options include induction loops, radar, pneumatic tubes, Bluetooth/Wi‑Fi probing, and human observation. Vision systems offer:

- Retrofit capability when cameras already exist  
- Classification of discrete vehicle categories (depending on detector training)  
- Rich spatial cues (lanes, overlaps, occlusion) usable for qualitative congestion  

Costs include **computational demand**, dependence on **viewpoint**, **illumination**, and **privacy** considerations (not deeply treated here but acknowledged).

This project concentrates on assembling a reproducible CV stack plus API/UI so behavioral results can be **observed**, **logged**, and **exported** rather than debating any single sensing modality as superior.

---

## 3. Project scope

### 3.1 In scope

- Single active video pipeline at a time (single stream/session in the prototype).  
- Vehicles only: detector restricted to automobile-related COCO-aligned classes usable by YOLOv8 pretrained weights.  
- Server-side inference; thin browser client polling JSON and displaying MJPEG.  
- Lightweight session analytics on the client (rolling history buffers, CSV/JSON download).  

### 3.2 Out of scope

- Calibration-grade ground truth validation, GIS registration, lane geometry mapping.  
- Multi-camera fusion or city-scale deployment topology.  
- Authentication, quotas, GDPR-style video retention policies.  
- Real-time actuator feedback to traffic signals.  

---

## 4. Objectives

### 4.1 Primary objectives

1. Deliver a robust **capture → perceive → quantify → visualize** pathway.  
2. Provide **explainable overlays** so a reviewer can correlate numeric metrics with the scene.  
3. Maintain a **simple HTTP contract** usable from any SPA or script.  

### 4.2 Secondary objectives

1. Optimize for **moderate CPU/GPU laptops** via frame skipping and resolution reduction.  
2. Support demo-friendly **automatic fallback** to a webcam when URLs fail locally.  
3. Allow **tabular export** of timestamped aggregates for coursework write-ups or plots.  

---

## 5. High-level architecture

Central idea: isolate **heavy CV work** in a background worker thread while **FastAPI request handlers remain lightweight**, returning the latest aggregated JSON and streaming JPEG composites.

### 5.1 Component diagram (logical)

```mermaid
flowchart LR
    subgraph ingestion [Video ingestion]
      URL[Stream URL]
      CAM[Fallback camera index 0]
    end
    
    subgraph processing [Vision pipeline]
      CV[OpenCV capture + resize]
      DET[YOLOv8 detector]
      TRK[IoU Hungarian tracker]
      SPD[Speed estimator]
      CONG[Congestion analyzer]
    end
    
    subgraph api [Presentation API]
      REST[REST JSON metrics]
      MJPEG[MJPEG multipart stream]
    end
    
    subgraph ui [Frontend]
      DASH[Next.js dashboard]
    end
    
    URL --> CV
    CAM --> CV
    CV --> DET --> TRK --> SPD --> CONG
    CONG --> REST
    CV --> MJPEG
    DET --> MJPEG
    TRK --> MJPEG
    SPD --> MJPEG
    REST --> DASH
    MJPEG --> DASH
```

### 5.2 Architectural responsibilities

| Subsystem | Responsibility |
|-----------|----------------|
| **`main.py`** | Application lifecycle; thread spawn; globals holding latest frame + metrics; HTTP routes. |
| **`detection.py`** | Loads Ultralytics `YOLO` weights; filters to vehicle classes; returns normalized detection dict list. |
| **`tracking.py`** | Maintains persistent `Track` instances; pairwise IoU scoring; bipartite optimum via **SciPy Hungarian** assignment. |
| **`speed.py`** | Frame-to-frame centroid displacement speed (pixels→meters heuristic) plus optional line-crossing refinement. |
| **`congestion.py`** | Derives categorical congestion, density statistic, smoothed categorical **trend** over deque history. |

---

## 6. Backend implementation detail

Runtime stack (see also `backend/requirements.txt`): **FastAPI**, **Uvicorn**, **OpenCV**, **PyTorch / TorchVision**, **Ultralytics YOLOv8**, **NumPy**, **SciPy**.

### 6.1 Application orchestration (`main.py`)

Upon `POST /start-stream`, unless a stream already runs:

1. Launch a **daemon worker thread** calling `process_stream(stream_url)`.  
2. Worker opens `cv2.VideoCapture(stream_url)`. If unreadable (`not cap.isOpened()`), revert to **`VideoCapture(0)`** enabling local webcam demonstrations.  
3. Query **FPS** through `CAP_PROP_FPS`; if positive, call `speed_estimator.set_fps(fps)` so time deltas align with nominal frame rate.  

Per iteration (while flag `stream_running` remains true):

- Read one frame; on failure briefly sleep/retry—tolerating transient network jitter.  
- Maintain a **parity counter**: process only **every second frame** (`frame_count % 2 == 0` skipped for odd frames reduces compute roughly two-fold versus full-rate).  
- **Resize** uniformly to `(640, 480)` balancing detector input size and labeling geometry.  

Pipeline order each processed frame:

1. `VehicleDetector.detect(frame)`  
2. `VehicleTracker.update(detections)`  
3. `SpeedEstimator.update(tracked)` returning per-ID km/h estimates  
4. Draw **cyan** and **green** horizontal guideline segments at estimator line `y` positions for visual grounding.  
5. Render green rectangles plus textual labels `{ID, class, optional speed km/h}`.  
6. `CongestionAnalyzer.analyze(tracked_count, speed_list)` merges into **`latest_metrics`** and stores **annotated** `latest_frame`.

The **`/video-feed`** route asynchronously streams JPEG-encoded boundaries using `multipart/x-mixed-replace` so browsers can `<img src=...>` the continuous sequence.

Concurrency note: Reads/writes on `latest_frame` / `latest_metrics` from multiple threads omit explicit locking in the prototype—a simplification adequate for demos but theoretically racy under extreme parallelism; hardened systems would synchronize or copy snapshot buffers atomically.

### 6.2 Vehicle detection (`detection.py`)

**Model:** Ultralytics pretrained `yolov8n.pt` (nano) downloadable at first inference.

**Hardware selection:** Prefer CUDA GPU, else Apple **MPS**, else CPU.

**Operational hyperparameters:**

| Parameter | Default | Role |
|-----------|---------|------|
| `conf` | `0.4` | Suppress noisy low-score boxes. |
| `iou` | `0.45` | Inference NMS threshold. |

Filtered **COCO class IDs** mapped to textual labels:

| ID | Semantic label |
|----|----------------|
| `2` | `car` |
| `5` | `bus` |
| `7` | `truck` |
| `3` | `motorcycle` |

Each detection export includes `'bbox'` integer tuple `(x1,y1,x2,y2)`, `'confidence'` rounded float, `'label'` string—feeds downstream tracking cleanly.

### 6.3 Object tracking (`tracking.py`)

Implemented as a pragmatic **appearance-free** tracker (no separate re-identification embeddings).

**Primitives:**

| Parameter | Meaning |
|-----------|---------|
| `max_age` | Missed-frame budget before pruning a dormant track (`5`). |
| `min_iou` | Minimum IoU to accept Hungarian-assigned pairing (`0.3`). |

**Algorithm skeleton per frame:**

1. If empties propagate missed counters & prune stale tracks returning survivors.  
2. Build rectangular **IoU matrix** `[detections × active tracks]` using standard intersection-over-union.  
3. Run **Hungarian optimum assignment** on **`-iou_matrix`** (SciPy maximizing IoU surrogate).  
4. Accept assignments only exceeding `min_iou`; spawn new tracks for unmatched detections; increment missed counters for orphaned tracks then prune.  

**Track state:** Bounding box geometry, centroid (integer midpoint), textual label/confidence recurrence, bookkeeping `missed_frames`.

Compared to heavyweight MOT libraries (DeepSORT, ByteTrack) this favors **implementational clarity**, smaller dependency surface, but may **ID-switch** more under heavy occlusion unless tuned.

### 6.4 Speed estimation (`speed.py`)

Hybrid strategy improving robustness for classroom demos:

#### A. Incremental centroid method

Uses consecutive processed-frame centroids. Pixel displacement \(\Delta p\) translates to meters via heuristic **`PIXELS_PER_METER = 50`** (user-tunable surrogate for focal length × mounting height interplay). Estimated meters per nominal frame interval:  
\[
v_{\mathrm{m/s}} = \frac{\Delta p / \mathrm{pixels\text{-}per\text{-}m}}{\mathrm{frame\_time}}, \quad v_{\mathrm{km/h}} = v_{\mathrm{m/s}}\times 3.6.
\]  
Tiny jitter (< `2 px`) ignored. History window max **10** stored speeds; surfaced value is **linearly weighted moving average** (recent frames weigh more heavily).

Limitation: Perspective foreshortening means equal pixel motion ≠ equal road distance across vertical image location without homography warp.

#### B. Dual-line crossing refinement

Predefined horizontal lines **`LINE_Y1 = 200`**, **`LINE_Y2 = 400`** (± `15 px` vertical tolerance capturing centroid crossings). Stores first-seen POSIX timestamps crossing each boundary. Upon both stored, recomputes:  
\[
v_{\mathrm{m/s}} = \frac{\mathtt{REAL\_DISTANCE\_METERS}}{\Delta t},\quad (\mathtt{default\ }10\ \mathrm{m}).
\]  
Converted to km/h; if positive replaces moving-average entry—offering stabilization when centroid delta noise spikes.

Operational dependency: Straight-line roadway alignment roughly orthogonal to downward camera gaze improves plausibility (still not surveying-grade).

#### C. Calibration surfaces

|Tunable constant | Typical adjustment scenario |
|------------------|------------------------------|
| `PIXELS_PER_METER` | Mount height / focal length tweaks |
| `LINE_Y1`, `LINE_Y2` | Place lines along known roadway segment |
| `REAL_DISTANCE_METERS` | Known ground truth span between crossings |

FPS auto-sync from capture lowers systematic drift tied to uneven frame pacing.

### 6.5 Congestion analysis (`congestion.py`)

Produces:

- **`vehicle_count`**: instantaneous active tracks feeding analyzer.  
- **`average_speed`**: arithmetic mean km/h (`0.0` if empty).  
- **`congestion_level`**: lexical category evaluated **in strict priority order** (first predicate match wins):

| Priority | Label | Predicate (vehicles=`c`, avg speed km/h=`s`) |
|----------|-------|---------------------------------------------|
| 1 | Critical | `c > 15` AND `s < 10` |
| 2 | High | `c > 10` AND `s < 20` |
| 3 | Medium | `c > 5` AND `s < 40` |
| 4 | Low | Fallback (always true if none earlier) |

The comment references **Highway Capacity Manual**–style intuition; thresholds here are illustrative not empirically city-calibrated.

**Density:** Vehicles per approximate million-pixel frame area \(\approx c / (\text{width}\times\text{height})\) normalized divisor.

**Trend:** Sliding deque (**length 30**) of categorical labels partitioned to compare mean ordinal score first vs second halves mapping `{Low:0 .. Critical:3}` ⇒ strings `improving`, `worsening`, `stable` with hysteresis epsilon `±0.2`.

### 6.6 JSON metrics payload shape

Each successful poll resembles:

```json
{
  "vehicle_count": 7,
  "average_speed": 18.5,
  "congestion_level": "Medium",
  "density": 0.06,
  "trend": "stable",
  "vehicles": [
    {"id": 3, "label": "car", "speed": 22.4}
  ]
}
```

Server zeroes suppressed speeds `< 0` for vehicle entries fed from pipeline (`0.0` placeholder while stabilizing).

### 6.7 HTTP API surface

| Method | Endpoint | Payload / behavior |
|--------|----------|--------------------|
| `GET` | `/` | Service banner JSON. |
| `GET` | `/health` | `{ "status": "ok" }` liveness. |
| `POST` | `/start-stream` | JSON body `{ "stream_url": "<uri>" }` spawns pipeline if idle. Returns duplicate notice if active. |
| `POST` | `/stop-stream` | Clears `stream_running`; thread eventually exits blocking read loop. |
| `GET` | `/metrics` | Latest aggregate metrics snapshot JSON. |
| `GET` | `/video-feed` | Continuous MJPEG `multipart/x-mixed-replace; boundary=frame`. |

Cross-Origin (`CORSMiddleware`) currently permissive (`allow_origins ["*"]`) for student development—would be narrowed in hardened deployments.

---

## 7. Frontend implementation detail

### 7.1 Technology selection

Primary framework **Next.js (App Router / client islands)** leveraging **Tailwind CSS** styling, **`framer-motion`** micro-interactions, **`axios`** HTTP client, **Recharts** chart primitives, **`react`/hooks** abstraction.

Environmental coupling: **`NEXT_PUBLIC_API_URL`** overriding default `http://localhost:8000`.

### 7.2 State orchestration patterns

Global UI session state encapsulated in **`MetricsProvider`** (`context/MetricsContext.tsx`):

- Latest server metrics object  
- Boolean streaming toggle + retained stream URL inputs  
- **Persistent vehicle registry** (`Map<id, PersistentVehicle>`) augmenting instantaneous detections with first/last timestamps, incremental detection counts, min/avg/max speed summaries, capped per-vehicle histories (`100` speed samples retained) enabling drill-down UX without querying historical backend storage.

### 7.3 Polling hooks

`useMetricsPolling`:

- Starts only when **`isStreaming` true**.  
- Initial immediate fetch followed by **`setInterval` ~ `500 ms`** (`METRICS_POLL_INTERVAL`) hitting `/metrics`.  
- Tracks consecutive failures (`maxRetries = 5`), surfacing degraded connection messaging suitable for diagnosing backend shutdown mid-demo.

Companion `useMetricsHistory` snapshots each successful payload into circular buffer (**`CHART_DATA_POINTS = 60`**) powering sparkline-style aggregates.

Vehicle selection helpers maintain per-session speed mini-series for plotting when a grid row expands.

### 7.4 Visualization components

| Component | Responsibility |
|-----------|----------------|
| `StreamControls` | Start/stop POST requests; persists URL defaults list from constants. |
| `VideoPlayer` | Assign `<img>` `src` to REST-assembled MJPEG URL; loaders & error overlays. |
| `MetricsCards` | Cardified headline KPI typography. |
| `VehicleList` / `VehicleDetailsPanel` | Tabular explorations & selection affordances |
| `AnalyticsCharts` | Recharts line/bar/area visualizations deriving numeric congestion surrogate for categorical labels (presentation simplification vs raw strings). |

### 7.5 Export utilities (`lib/export.ts`)

Client-only **blob downloads**:

- CSV with columns Timestamp, Printable Date, Vehicle Count, Avg Speed, Congestion Label.  
- JSON bundling summarized peak statistics counts (explicit filters currently aligned to categorical strings `Low|Medium|High` in summary aggregator—alignment with **`Critical`** label from backend summaries may merit future harmonization if strict analytics parity matters).

Exports support attaching evidence artifacts to coursework submissions without database persistence.

### 7.6 UI affordances elsewhere

Landing / marketing-esque sections (`Homepage`, About) narrate capability for external stakeholders; nonessential to core analytics pathway but scaffold professional presentation.

---

## 8. Data flow timelines

Typical synchronous request path (metrics):

1. Browser polls `GET /metrics` each 500 ms.  
2. Handler returns latest Python dict serialization—no recomputation latency inside request path aside from serialization.  

Video path runs **decoupled** in worker feeding asynchronous JPEG multipart generator sleeping ~33 ms between attempts (`~30 FPS` pacing target—not guaranteed synchronous with ingestion FPS).

Worst qualitative latency contributors: inference time per processed frame | network jitter on MJPEG | browser repaint scheduling.

---

## 9. Configuration & tuning playbook

Operational adjustments most likely during deployment experiments:

| Area | Adjustment lever | Intended effect |
|------|------------------|-----------------|
| Accuracy vs throughput | Detector model (`yolov8n` ↔ `small`) | Recall/precision-speed trade-space |
| False positives | Raise `VehicleDetector.conf` | Fewer tentative boxes |
| Track continuity | Tune `max_age`, `min_iou` | ID persistence vs phantom merges |
| Speed plausibility | Calibrate pixels/meter | Scale speeds toward realistic roadway magnitudes |
| Congestion thresholds | Rewrite predicates | Domain-specific escalation sensitivity |
| UI cadence | `METRICS_POLL_INTERVAL` | Reduced server chatter vs responsiveness |

Include README-style command reminders (adapt to local virtualenv tooling):

Backend (illustrative): `uvicorn main:app --reload --host 0.0.0.0 --port 8000` from `backend/` after dependency install.

Frontend: `npm install && npm run dev` inside `frontend/` with API URL environment variable if non-default.

---

## 10. Testing and validation strategy

Recommended layered approach (not all necessarily automated in repository):

1. **Unit sanity:** Synthetic IoU matrix assignment behavior; congestion predicate boundary tests.  
2. **Integration:** Recorded short MP4 loop via `VideoCapture` verifying monotonic track age increments & clean shutdown.  
3. **System:** Manual cross-check between on-frame printed speeds vs instantaneous `/metrics`.  
4. **Stress qualitative:** Busy clip vs sparse clip ensuring chart buffers stay bounded (`CHART_DATA_POINTS`).  

Formal accuracy benchmarking would require calibrated ground truth overlays (beyond prototype scope).

---

## 11. Security, ethics, deployment caveats

- Open CORS permissive ⇒ must not expose raw WAN without reverse proxy constraints.  
- Video may capture faces/license plates ⇒ operational privacy review required for production.  
- Speed outputs **not legally binding** absent metrology pipelines and jurisdictional approvals.  

---

## 12. Known limitations summary

| Category | Limitation |
|----------|------------|
| Algorithmic | Simplified tracker vs state-of-art MOT benchmarks; perspective un-modeled planar speed heuristic | 
| Architectural | Race-free concurrency not formally guaranteed across shared globals | 
| Scalability | Single-stream single-process; MJPEG simplistic under lossy WAN | 
| Consistency edge cases | Frontend TypeScript enums partially assume three-tier congestion labeling while backend emits **Critical** in heavy scenarios | 

These are intentional simplifications aligning with exploratory academic scope.

---

## 13. Future work

1. Perspective rectification (**homography** from manual lane calibration anchors).  
2. Replace centroid heuristics with **ByteTrack**, **StrongSORT**, or ONNX-optimized trackers.  
3. Add authentication + user-scoped stream registry.  
4. GPU batching pipeline or TensorRT distilled model for edge hardware.  
5. Historical database (PostgreSQL/Timescale) replacing ephemeral client buffers for audits.  

---

## 14. Conclusion

The constructed system fulfills a pedagogical mandate: unify **streaming perception**, analytic summarization, and **interactive visualization**. It underscores both the expressive power—rapid insights from unstructured video—and the engineering debt—calibration discipline, probabilistic correctness, concurrency hygiene—between a **demo-ready prototype** and a **regulated transportation product**.

---

## References and further reading

1. Ultralytics YOLOv8 documentation (`https://docs.ultralytics.com`).  
2. OpenCV Video I/O guides (`https://docs.opencv.org`).  
3. FastAPI streaming responses (`https://fastapi.tiangolo.com/advanced/custom-response`).  
4. Next.js documentation (`https://nextjs.org/docs`).  
5. Recharts visualization library (`https://recharts.org`).  
6. SciPy linear assignment algorithm background (Jonker–Volgenant implementation used via `linear_sum_assignment`).  

---

## Appendix A: Backend dependency manifest (as declared)

```
fastapi
uvicorn
opencv-python
torch
torchvision
ultralytics
numpy
Pillow
python-multipart
scipy
```

*End of report.*
