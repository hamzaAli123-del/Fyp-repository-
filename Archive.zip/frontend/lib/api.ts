import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_URL,
  timeout: 10000,
});

export interface Vehicle {
  id: number;
  label: string;
  speed: number | null;
}

export interface Metrics {
  vehicle_count: number;
  average_speed: number;
  congestion_level: 'Low' | 'Medium' | 'High';
  vehicles: Vehicle[];
}

export interface StreamRequest {
  stream_url: string;
}

export const apiClient = {
  health: () => api.get('/health'),
  
  startStream: (streamUrl: string) =>
    api.post<{ message: string }>('/start-stream', { stream_url: streamUrl }),
  
  stopStream: () =>
    api.post<{ message: string }>('/stop-stream'),
  
  getMetrics: () =>
    api.get<Metrics>('/metrics'),
  
  // Get video feed stream
  getVideoFeed: () => `${API_URL}/video-feed`,
};

export default api;
