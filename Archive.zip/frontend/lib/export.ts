'use client';

import { MetricsSnapshot } from '@/hooks/useMetricsHistory';

export const exportAsCSV = (
  history: MetricsSnapshot[],
  filename: string = 'traffic-metrics.csv'
) => {
  if (history.length === 0) {
    alert('No data to export');
    return;
  }

  const headers = ['Timestamp', 'Date/Time', 'Vehicle Count', 'Avg Speed (km/h)', 'Congestion Level'];
  const rows = history.map((item) => [
    item.timestamp,
    new Date(item.timestamp).toLocaleString(),
    item.vehicle_count,
    item.average_speed.toFixed(2),
    item.congestion_level,
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const exportAsJSON = (
  history: MetricsSnapshot[],
  filename: string = 'traffic-metrics.json'
) => {
  if (history.length === 0) {
    alert('No data to export');
    return;
  }

  const data = {
    exportDate: new Date().toISOString(),
    dataPoints: history.length,
    metrics: history.map((item) => ({
      timestamp: item.timestamp,
      dateTime: new Date(item.timestamp).toISOString(),
      vehicle_count: item.vehicle_count,
      average_speed: item.average_speed,
      congestion_level: item.congestion_level,
    })),
    summary: {
      totalDataPoints: history.length,
      peakVehicleCount: Math.max(...history.map((h) => h.vehicle_count)),
      peakAverageSpeed: Math.max(...history.map((h) => h.average_speed)),
      averageAverageSpeed:
        history.reduce((sum, h) => sum + h.average_speed, 0) / history.length,
      highCongestionCount: history.filter(
        (h) => h.congestion_level === 'High'
      ).length,
      mediumCongestionCount: history.filter(
        (h) => h.congestion_level === 'Medium'
      ).length,
      lowCongestionCount: history.filter(
        (h) => h.congestion_level === 'Low'
      ).length,
    },
  };

  const jsonContent = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonContent], {
    type: 'application/json;charset=utf-8;',
  });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
