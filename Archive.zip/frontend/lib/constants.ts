// Default stream URLs for examples
export const DEFAULT_STREAM_URLS = [
  'http://example.com/stream.m3u8',
  'rtsp://example.com/stream',
  'https://test-streams.mux.dev/x36xhzz/x3runxmf93.m3u8',
];

// Polling intervals (ms)
export const METRICS_POLL_INTERVAL = 500;
export const HEALTH_CHECK_INTERVAL = 5000;

// Chart settings
export const CHART_DATA_POINTS = 60;
export const CHART_UPDATE_INTERVAL = 500;

// Video quality presets
export const VIDEO_QUALITIES = [
  { label: 'Low (480p)', value: '480p' },
  { label: 'Medium (720p)', value: '720p' },
  { label: 'High (1080p)', value: '1080p' },
];

// Congestion color mapping
export const CONGESTION_COLORS = {
  'Low': '#10b981', // green
  'Medium': '#f59e0b', // amber
  'High': '#ef4444', // red
};

// Vehicle type colors
export const VEHICLE_COLORS = {
  'car': '#3b82f6', // blue
  'truck': '#8b5cf6', // purple
  'bus': '#f59e0b', // amber
  'motorcycle': '#ec4899', // pink
};
