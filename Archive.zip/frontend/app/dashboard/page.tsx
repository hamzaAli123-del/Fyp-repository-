'use client';

import React from 'react';
import { motion } from 'framer-motion';
import Navbar from '@/components/home/Navbar';
import { VideoPlayer } from '@/components/VideoPlayer';
import { StreamControls } from '@/components/StreamControls';
import { MetricsCards } from '@/components/MetricsCards';
import { VehicleList } from '@/components/VehicleList';
import { VehicleDetailsPanel } from '@/components/VehicleDetailsPanel';
import { AnalyticsCharts } from '@/components/AnalyticsCharts';
import { ExportButtons } from '@/components/ExportButtons';
import { useMetrics } from '@/context/MetricsContext';
import { useMetricsPolling } from '@/hooks/useMetricsPolling';
import { useVehicleSelection } from '@/hooks/useVehicleSelection';
import { useMetricsHistory } from '@/hooks/useMetricsHistory';
import Footer from '@/components/home/Footer';
function SectionHeader({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <h2 className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 whitespace-nowrap">
        {children}
      </h2>
      <div className="flex-1 h-px bg-gradient-to-r from-gray-200 dark:from-gray-700 to-transparent" />
    </div>
  );
}

export default function Dashboard() {
  const {
    metrics,
    updateMetrics,
    isStreaming,
    setIsStreaming,
    streamUrl,
    setStreamUrl,
  } = useMetrics();

  const {
    selectedVehicle,
    selectVehicle,
    updateVehicleHistory,
    getVehicleSpeedHistory,
  } = useVehicleSelection();

  const { history, addSnapshot } = useMetricsHistory();

  const { error: metricsError } = useMetricsPolling(
    (newMetrics) => {
      updateMetrics(newMetrics);
      updateVehicleHistory(newMetrics.vehicles);
      addSnapshot(newMetrics);
      if (
        selectedVehicle &&
        !newMetrics.vehicles.find((v) => v.id === selectedVehicle.id)
      ) {
        selectVehicle(null);
      }
    },
    isStreaming
  );

  const selectedVehicleSpeedHistory = selectedVehicle
    ? getVehicleSpeedHistory(selectedVehicle.id)
    : [];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-950 transition-colors duration-300">
      <Navbar />

      {/* ── Header ── */}
      <header className="mt-20 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="flex flex-col gap-1 p-2 bg-gray-100 dark:bg-gray-800 rounded-xl">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-sm shadow-red-500/60" />
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 shadow-sm shadow-yellow-400/60" />
                <div className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-sm shadow-green-500/60" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white leading-tight">
                  Traffic Management System
                </h1>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
                  Real-time vehicle tracking &amp; congestion analysis
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all duration-300 ${
                isStreaming
                  ? 'bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/30 text-green-700 dark:text-green-400'
                  : 'bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-500 dark:text-gray-400'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${isStreaming ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
                {isStreaming ? 'Live' : 'Offline'}
              </div>
              {metricsError && (
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30 text-red-700 dark:text-red-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                  Backend unreachable
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* ── Main Content ── */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">

          {/* Left: Video + Controls */}
          <div className="lg:col-span-2 space-y-5">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden"
            >
              <div className="px-5 pt-5 pb-2">
                <SectionHeader>Live Video Feed</SectionHeader>
              </div>
              <div className="px-5 pb-5">
                <VideoPlayer isStreaming={isStreaming} />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.06 }}
              className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-5"
            >
              <SectionHeader>Stream Control</SectionHeader>
              <StreamControls
                onStreamStart={() => setIsStreaming(true)}
                onStreamStop={() => setIsStreaming(false)}
                isStreaming={isStreaming}
                onStreamUrlChange={setStreamUrl}
              />
            </motion.div>
          </div>

          {/* Center: Metrics + Vehicles */}
          <div className="lg:col-span-1 space-y-5">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.1 }}
              className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-5"
            >
              <SectionHeader>Real-time Metrics</SectionHeader>
              <MetricsCards metrics={metrics} isStreaming={isStreaming} />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.14 }}
              className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-5"
            >
              <SectionHeader>Tracked Vehicles</SectionHeader>
              <VehicleList
                vehicles={metrics?.vehicles ?? []}
                selectedVehicle={selectedVehicle}
                onSelectVehicle={selectVehicle}
                isStreaming={isStreaming}
              />
            </motion.div>
          </div>

          {/* Right: Vehicle Details */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.18 }}
              className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-5 sticky top-24"
            >
              <SectionHeader>Vehicle Details</SectionHeader>
              <VehicleDetailsPanel
                vehicle={selectedVehicle}
                speedHistory={selectedVehicleSpeedHistory}
              />
            </motion.div>
          </div>
        </div>

        {/* ── Analytics ── */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.22 }}
          className="mt-6"
        >
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">Historical Analytics</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
                  {history.length > 0 ? `${history.length} data points collected` : 'Start a stream to collect data'}
                </p>
              </div>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
                ◈
              </div>
            </div>
            <AnalyticsCharts history={history} isStreaming={isStreaming} />
          </div>
        </motion.div>

        {/* ── Summary + Export ── */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.28 }}
          className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6"
        >
          <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-6">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-5">Session Summary</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                {
                  label: 'Duration',
                  value: history.length > 0
                    ? `${Math.round((history[history.length - 1].timestamp - history[0].timestamp) / 1000 / 60)} min`
                    : '—',
                  cls: 'bg-blue-50 dark:bg-blue-500/10 border-blue-200 dark:border-blue-500/20 text-blue-700 dark:text-blue-400',
                },
                {
                  label: 'Avg Vehicles',
                  value: history.length > 0
                    ? (history.reduce((s, h) => s + h.vehicle_count, 0) / history.length).toFixed(1)
                    : '—',
                  cls: 'bg-purple-50 dark:bg-purple-500/10 border-purple-200 dark:border-purple-500/20 text-purple-700 dark:text-purple-400',
                },
                {
                  label: 'Avg Speed',
                  value: history.length > 0
                    ? `${(history.reduce((s, h) => s + h.average_speed, 0) / history.length).toFixed(1)} km/h`
                    : '—',
                  cls: 'bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/20 text-green-700 dark:text-green-400',
                },
                {
                  label: 'High Congestion',
                  value: history.length > 0
                    ? `${((history.filter((h) => h.congestion_level === 'High').length / history.length) * 100).toFixed(0)}%`
                    : '—',
                  cls: 'bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400',
                },
              ].map((stat) => (
                <div key={stat.label} className={`rounded-xl p-4 border ${stat.cls}`}>
                  <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{stat.label}</p>
                  <p className={`text-xl font-bold`}>{stat.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-6">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-5">Export Data</h2>
            <ExportButtons history={history} isStreaming={isStreaming} />
          </div>
        </motion.div>
      </main>

      {/* ── Footer ── */}
      <Footer />
    </div>
  );
}
