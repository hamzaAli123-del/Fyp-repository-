import Navbar from '@/components/home/Navbar';
import AboutSection from '@/components/home/AboutSection';
import Footer from '@/components/home/Footer';

export default function About() {
  return (
    <div>
      <Navbar />
      <AboutSection />
      <Footer />
    </div>
  );
}
