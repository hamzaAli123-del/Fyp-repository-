'use client';

import React, { useState, useEffect } from 'react';
import { VideoPlayer } from '@/components/VideoPlayer';
import { StreamControls } from '@/components/StreamControls';
import { MetricsCards } from '@/components/MetricsCards';
import { VehicleList } from '@/components/VehicleList';
import { VehicleDetailsPanel } from '@/components/VehicleDetailsPanel';
import { useMetrics } from '@/context/MetricsContext';
import { useMetricsPolling } from '@/hooks/useMetricsPolling';
import { useVehicleSelection } from '@/hooks/useVehicleSelection';

export default function Home() {
  const {
    metrics,
    updateMetrics,
    isStreaming,
    setIsStreaming,
    streamUrl,
    setStreamUrl,
  } = useMetrics();

  const {
    selectedVehicle,
    selectVehicle,
    updateVehicleHistory,
    getVehicleSpeedHistory,
  } = useVehicleSelection();

  const { error: metricsError } = useMetricsPolling(
    (newMetrics) => {
      updateMetrics(newMetrics);
      updateVehicleHistory(newMetrics.vehicles);
      
      // Auto-deselect vehicle if it's no longer tracked
      if (
        selectedVehicle &&
        !newMetrics.vehicles.find((v) => v.id === selectedVehicle.id)
      ) {
        selectVehicle(null);
      }
    },
    isStreaming
  );

  const selectedVehicleSpeedHistory = selectedVehicle
    ? getVehicleSpeedHistory(selectedVehicle.id)
    : [];

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-black">
      {/* Header */}
      <header className="border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                🚦 Traffic Management System
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Real-time vehicle tracking and congestion analysis
              </p>
            </div>
            {metricsError && (
              <div className="px-4 py-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <p className="text-sm text-red-700 dark:text-red-400">
                  ⚠️ {metricsError}
                </p>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Column: Video */}
          <div className="lg:col-span-2">
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  Live Video Feed
                </h2>
                <VideoPlayer isStreaming={isStreaming} />
              </div>

              <div>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  Stream Control
                </h2>
                <StreamControls
                  onStreamStart={() => setIsStreaming(true)}
                  onStreamStop={() => setIsStreaming(false)}
                  isStreaming={isStreaming}
                  onStreamUrlChange={setStreamUrl}
                />
              </div>
            </div>
          </div>

          {/* Center Column: Metrics & Vehicles */}
          <div className="lg:col-span-1">
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  Real-time Metrics
                </h2>
                <MetricsCards metrics={metrics} isStreaming={isStreaming} />
              </div>

              <div>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  Tracked Vehicles
                </h2>
                <VehicleList
                  vehicles={metrics?.vehicles ?? []}
                  selectedVehicle={selectedVehicle}
                  onSelectVehicle={selectVehicle}
                  isStreaming={isStreaming}
                />
              </div>
            </div>
          </div>

          {/* Right Column: Vehicle Details */}
          <div className="lg:col-span-1">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                Vehicle Details
              </h2>
              <VehicleDetailsPanel
                vehicle={selectedVehicle}
                speedHistory={selectedVehicleSpeedHistory}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-sm text-gray-600 dark:text-gray-400">
          <p>Backend API: {process.env.NEXT_PUBLIC_API_URL}</p>
        </div>
      </footer>
    </div>
  );
}
