'use client';

import { useState, useCallback } from 'react';
import { Vehicle } from '@/lib/api';

export interface PersistentVehicle extends Vehicle {
  firstSeen: number;
  lastSeen: number;
  totalDetections: number;
  averageSpeed: number;
  maxSpeed: number;
  minSpeed: number;
  isCurrentlyDetected: boolean;
  speeds: number[];
}

export const usePersistentVehicles = () => {
  const [vehicleRegistry, setVehicleRegistry] = useState<Map<number, PersistentVehicle>>(new Map());

  const updateVehicles = useCallback((vehicles: Vehicle[]) => {
    const now = Date.now();

    setVehicleRegistry((prevRegistry) => {
      const newRegistry = new Map(prevRegistry);

      // Mark all vehicles as not currently detected
      newRegistry.forEach((vehicle) => {
        vehicle.isCurrentlyDetected = false;
        vehicle.lastSeen = now;
      });

      // Update or create vehicles from current detection
      vehicles.forEach((vehicle) => {
        const existing = newRegistry.get(vehicle.id);

        if (existing) {
          // Update existing vehicle
          const speeds = [...existing.speeds];
          if (vehicle.speed !== null && vehicle.speed > 0) {
            speeds.push(vehicle.speed);
            // Keep only last 100 samples
            if (speeds.length > 100) {
              speeds.shift();
            }
          }

          const validSpeeds = speeds.filter(s => s > 0);
          const avgSpeed = validSpeeds.length > 0
            ? validSpeeds.reduce((a, b) => a + b, 0) / validSpeeds.length
            : 0;
          const maxSpeed = validSpeeds.length > 0 ? Math.max(...validSpeeds) : 0;
          const minSpeed = validSpeeds.length > 0 ? Math.min(...validSpeeds) : 0;

          newRegistry.set(vehicle.id, {
            ...existing,
            ...vehicle,
            lastSeen: now,
            totalDetections: existing.totalDetections + 1,
            averageSpeed: Math.round(avgSpeed * 10) / 10,
            maxSpeed: Math.round(maxSpeed * 10) / 10,
            minSpeed: Math.round(minSpeed * 10) / 10,
            isCurrentlyDetected: true,
            speeds,
          });
        } else {
          // Create new vehicle
          const speeds = vehicle.speed !== null && vehicle.speed > 0 ? [vehicle.speed] : [];

          newRegistry.set(vehicle.id, {
            ...vehicle,
            firstSeen: now,
            lastSeen: now,
            totalDetections: 1,
            averageSpeed: vehicle.speed || 0,
            maxSpeed: vehicle.speed || 0,
            minSpeed: vehicle.speed || 0,
            isCurrentlyDetected: true,
            speeds,
          });
        }
      });

      return newRegistry;
    });
  }, []);

  const getAllVehicles = useCallback(() => {
    return Array.from(vehicleRegistry.values()).sort((a, b) => b.lastSeen - a.lastSeen);
  }, [vehicleRegistry]);

  const getVehicleById = useCallback((id: number) => {
    return vehicleRegistry.get(id) || null;
  }, [vehicleRegistry]);

  const getCurrentlyDetectedVehicles = useCallback(() => {
    return Array.from(vehicleRegistry.values())
      .filter(v => v.isCurrentlyDetected)
      .sort((a, b) => a.id - b.id);
  }, [vehicleRegistry]);

  const clearRegistry = useCallback(() => {
    setVehicleRegistry(new Map());
  }, []);

  const getSessionStats = useCallback(() => {
    const allVehicles = Array.from(vehicleRegistry.values());
    const totalVehicles = allVehicles.length;
    const currentlyDetected = allVehicles.filter(v => v.isCurrentlyDetected).length;

    const allSpeeds = allVehicles
      .flatMap(v => v.speeds)
      .filter(s => s > 0);

    const avgSpeed = allSpeeds.length > 0
      ? allSpeeds.reduce((a, b) => a + b, 0) / allSpeeds.length
      : 0;

    return {
      totalVehicles,
      currentlyDetected,
      averageSpeed: Math.round(avgSpeed * 10) / 10,
      totalDetections: allVehicles.reduce((sum, v) => sum + v.totalDetections, 0),
    };
  }, [vehicleRegistry]);

  return {
    vehicleRegistry,
    updateVehicles,
    getAllVehicles,
    getVehicleById,
    getCurrentlyDetectedVehicles,
    clearRegistry,
    getSessionStats,
  };
};

export const useVehicleSelection = () => {
  const [selectedVehicle, setSelectedVehicle] = useState<PersistentVehicle | null>(null);
  const [vehicleSpeedHistory, setVehicleSpeedHistory] = useState<
    Map<number, number[]>
  >(new Map());

  const selectVehicle = useCallback((vehicle: PersistentVehicle | null) => {
    setSelectedVehicle(vehicle);
  }, []);

  const updateVehicleHistory = useCallback((vehicles: Vehicle[]) => {
    setVehicleSpeedHistory((prev) => {
      const newHistory = new Map(prev);

      vehicles.forEach((vehicle) => {
        if (vehicle.speed !== null && vehicle.speed > 0) {
          if (!newHistory.has(vehicle.id)) {
            newHistory.set(vehicle.id, []);
          }
          const history = newHistory.get(vehicle.id)!;
          history.push(vehicle.speed);

          // Keep only last 30 samples per vehicle
          if (history.length > 30) {
            history.shift();
          }
        }
      });

      return newHistory;
    });
  }, []);

  const getVehicleSpeedHistory = useCallback((vehicleId: number) => {
    return vehicleSpeedHistory.get(vehicleId) || [];
  }, [vehicleSpeedHistory]);

  return {
    selectedVehicle,
    selectVehicle,
    updateVehicleHistory,
    getVehicleSpeedHistory,
  };
};
