'use client';

import { useEffect, useRef, useState } from 'react';
import { apiClient, Metrics } from '@/lib/api';
import { METRICS_POLL_INTERVAL } from '@/lib/constants';

export const useMetricsPolling = (
  onMetricsUpdate: (metrics: Metrics) => void,
  isStreaming: boolean
) => {
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const retryCountRef = useRef(0);
  const callbackRef = useRef(onMetricsUpdate);
  const maxRetries = 5;

  // Update callback ref without affecting effect
  useEffect(() => {
    callbackRef.current = onMetricsUpdate;
  }, [onMetricsUpdate]);

  // Setup polling effect
  useEffect(() => {
    if (!isStreaming) {
      // Clean up polling if not streaming
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      retryCountRef.current = 0;
      return;
    }

    // Fetch metrics function
    const fetchMetrics = async () => {
      try {
        setIsLoading(true);
        const response = await apiClient.getMetrics();
        callbackRef.current(response.data);
        setError(null);
        retryCountRef.current = 0;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Failed to fetch metrics';
        setError(errorMsg);
        retryCountRef.current += 1;

        if (retryCountRef.current > maxRetries) {
          setError('Connection lost. Stream may have stopped.');
        }
      } finally {
        setIsLoading(false);
      }
    };

    // Fetch immediately
    fetchMetrics();
    
    // Setup interval
    intervalRef.current = setInterval(fetchMetrics, METRICS_POLL_INTERVAL);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isStreaming]);

  return { error, isLoading };
};
