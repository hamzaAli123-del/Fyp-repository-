'use client';

import { useState, useCallback, useRef } from 'react';
import { Metrics } from '@/lib/api';
import { CHART_DATA_POINTS } from '@/lib/constants';

export interface MetricsSnapshot {
  timestamp: number;
  vehicle_count: number;
  average_speed: number;
  congestion_level: 'Low' | 'Medium' | 'High';
}

export const useMetricsHistory = () => {
  const [history, setHistory] = useState<MetricsSnapshot[]>([]);
  const bufferRef = useRef<MetricsSnapshot[]>([]);

  const addSnapshot = useCallback((metrics: Metrics) => {
    const snapshot: MetricsSnapshot = {
      timestamp: Date.now(),
      vehicle_count: metrics.vehicle_count,
      average_speed: metrics.average_speed,
      congestion_level: metrics.congestion_level,
    };

    bufferRef.current.push(snapshot);

    // Keep only last CHART_DATA_POINTS
    if (bufferRef.current.length > CHART_DATA_POINTS) {
      bufferRef.current.shift();
    }

    setHistory([...bufferRef.current]);
  }, []);

  const getHistory = useCallback(() => {
    return history;
  }, [history]);

  const clearHistory = useCallback(() => {
    bufferRef.current = [];
    setHistory([]);
  }, []);

  return {
    history,
    addSnapshot,
    getHistory,
    clearHistory,
  };
};
