'use client';

import React, { useState, useEffect } from 'react';
import { apiClient } from '@/lib/api';
import { DEFAULT_STREAM_URLS } from '@/lib/constants';

interface StreamControlsProps {
  onStreamStart: () => void;
  onStreamStop: () => void;
  isStreaming: boolean;
  onStreamUrlChange: (url: string) => void;
}

export const StreamControls: React.FC<StreamControlsProps> = ({
  onStreamStart,
  onStreamStop,
  isStreaming,
  onStreamUrlChange,
}) => {
  const [streamUrl, setStreamUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('lastStreamUrl');
    if (saved) {
      setStreamUrl(saved);
      onStreamUrlChange(saved);
    } else {
      setStreamUrl(DEFAULT_STREAM_URLS[0]);
    }
  }, [onStreamUrlChange]);

  const handleStart = async () => {
    if (!streamUrl.trim()) {
      setError('Please enter a stream URL');
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      await apiClient.startStream(streamUrl);
      localStorage.setItem('lastStreamUrl', streamUrl);
      onStreamUrlChange(streamUrl);
      onStreamStart();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start stream');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStop = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await apiClient.stopStream();
      onStreamStop();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to stop stream');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {/* URL input row */}
      <div>
        <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">
          Stream URL
        </label>
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                  d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
            </div>
            <input
              type="text"
              value={streamUrl}
              onChange={(e) => { setStreamUrl(e.target.value); setError(null); }}
              placeholder="rtsp:// or http://…"
              disabled={isStreaming || isLoading}
              className="w-full pl-9 pr-8 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 text-sm disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
            />
            {streamUrl && !isStreaming && (
              <button
                onClick={() => setStreamUrl('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
              >
                ✕
              </button>
            )}
          </div>

          {/* Examples dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              disabled={isStreaming}
              className="px-3 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-xs font-semibold text-gray-600 dark:text-gray-300 transition-colors whitespace-nowrap"
            >
              Examples
            </button>
            {showDropdown && (
              <div className="absolute right-0 mt-1 min-w-48 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-xl z-20 overflow-hidden">
                {DEFAULT_STREAM_URLS.map((url, idx) => (
                  <button
                    key={idx}
                    onClick={() => { setStreamUrl(url); setShowDropdown(false); }}
                    className="w-full text-left px-4 py-2.5 text-xs text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors truncate"
                  >
                    {url}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-start gap-2 px-3 py-2.5 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-xs">
          <span className="mt-0.5">⚠️</span>
          <span>{error}</span>
        </div>
      )}

      {/* Action button */}
      {!isStreaming ? (
        <button
          onClick={handleStart}
          disabled={isLoading || !streamUrl.trim()}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:from-gray-300 disabled:to-gray-400 dark:disabled:from-gray-700 dark:disabled:to-gray-600 disabled:cursor-not-allowed text-white font-semibold text-sm transition-all duration-200 shadow-sm hover:shadow-md disabled:shadow-none flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              Connecting…
            </>
          ) : (
            <>▶ Start Stream</>
          )}
        </button>
      ) : (
        <button
          onClick={handleStop}
          disabled={isLoading}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold text-sm transition-all duration-200 shadow-sm hover:shadow-md flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              Stopping…
            </>
          ) : (
            <>■ Stop Stream</>
          )}
        </button>
      )}

      {/* Status line */}
      <div className="flex items-center gap-2 text-xs text-gray-400 dark:text-gray-500">
        <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${isStreaming ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
        {isStreaming ? 'Stream active — receiving data' : 'Stream inactive'}
      </div>
    </div>
  );
};
