'use client';

import React, { useEffect, useRef, useState } from 'react';
import { apiClient } from '@/lib/api';

interface VideoPlayerProps {
  isStreaming: boolean;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ isStreaming }) => {
  const imgRef = useRef<HTMLImageElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isStreaming) {
      setError(null);
      setIsLoading(false);
      if (imgRef.current) imgRef.current.src = '';
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const videoFeedUrl = apiClient.getVideoFeed();
      if (imgRef.current) {
        imgRef.current.src = videoFeedUrl;
        imgRef.current.onload = () => setIsLoading(false);
        imgRef.current.onerror = () => {
          setError('Failed to load video stream');
          setIsLoading(false);
        };
      }
    } catch {
      setError('Error loading video stream');
      setIsLoading(false);
    }
  }, [isStreaming]);

  return (
    <div className="flex flex-col gap-3">
      <div className="relative w-full bg-gray-950 rounded-xl overflow-hidden aspect-video flex items-center justify-center">
        {/* Loading overlay */}
        {isLoading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-950/80 backdrop-blur-sm z-10 gap-3">
            <div className="w-8 h-8 rounded-full border-2 border-blue-500/30 border-t-blue-500 animate-spin" />
            <p className="text-xs text-gray-400 font-medium">Connecting to stream…</p>
          </div>
        )}

        {/* Error state */}
        {error ? (
          <div className="flex flex-col items-center gap-3 px-6 text-center">
            <div className="w-12 h-12 rounded-full bg-red-500/10 flex items-center justify-center text-2xl">
              ⚠️
            </div>
            <div>
              <p className="text-red-400 text-sm font-medium">{error}</p>
              <p className="text-gray-500 text-xs mt-1">Make sure the backend is running</p>
            </div>
          </div>
        ) : isStreaming ? (
          <img
            ref={imgRef}
            alt="Live video feed"
            className="w-full h-full object-cover"
          />
        ) : (
          /* Offline placeholder */
          <div className="flex flex-col items-center gap-4 px-6 text-center">
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-gray-800 flex items-center justify-center">
                <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M15 10l4.553-2.069A1 1 0 0121 8.82v6.36a1 1 0 01-1.447.894L15 14M3 8a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
                </svg>
              </div>
            </div>
            <div>
              <p className="text-gray-400 text-sm font-medium">No stream active</p>
              <p className="text-gray-600 text-xs mt-1">Enter a URL below and press Start</p>
            </div>
          </div>
        )}

        {/* LIVE badge */}
        {isStreaming && !isLoading && !error && (
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-sm border border-white/10">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs font-bold text-white tracking-widest">LIVE</span>
          </div>
        )}
      </div>
    </div>
  );
};
