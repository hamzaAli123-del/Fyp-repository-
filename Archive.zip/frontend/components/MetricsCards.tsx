'use client';

import React from 'react';
import { Metrics } from '@/lib/api';

interface MetricsCardsProps {
  metrics: Metrics | null;
  isStreaming: boolean;
}

export const MetricsCards: React.FC<MetricsCardsProps> = ({ metrics, isStreaming }) => {
  const congestion = metrics?.congestion_level ?? 'N/A';

  const congestionConfig = {
    Low: { bar: 'bg-green-500', text: 'text-green-700 dark:text-green-400', bg: 'bg-green-50 dark:bg-green-500/10', border: 'border-green-200 dark:border-green-500/20', pct: 33 },
    Medium: { bar: 'bg-amber-500', text: 'text-amber-700 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-500/10', border: 'border-amber-200 dark:border-amber-500/20', pct: 66 },
    High: { bar: 'bg-red-500', text: 'text-red-700 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-500/10', border: 'border-red-200 dark:border-red-500/20', pct: 100 },
  }[congestion] ?? { bar: 'bg-gray-400', text: 'text-gray-500 dark:text-gray-400', bg: 'bg-gray-50 dark:bg-gray-800/50', border: 'border-gray-200 dark:border-gray-700', pct: 0 };

  const cards = [
    {
      icon: '🚗',
      label: 'Vehicle Count',
      value: metrics?.vehicle_count !== undefined ? metrics.vehicle_count.toString() : '—',
      sub: 'detected',
      bg: 'bg-blue-50 dark:bg-blue-500/10',
      border: 'border-blue-200 dark:border-blue-500/20',
      text: 'text-blue-700 dark:text-blue-400',
      iconBg: 'bg-blue-100 dark:bg-blue-500/20',
    },
    {
      icon: '⚡',
      label: 'Average Speed',
      value: metrics?.average_speed !== undefined ? metrics.average_speed.toFixed(1) : '—',
      sub: 'km/h',
      bg: 'bg-purple-50 dark:bg-purple-500/10',
      border: 'border-purple-200 dark:border-purple-500/20',
      text: 'text-purple-700 dark:text-purple-400',
      iconBg: 'bg-purple-100 dark:bg-purple-500/20',
    },
  ];

  return (
    <div className={`space-y-3 transition-opacity duration-300 ${!isStreaming ? 'opacity-50' : ''}`}>
      {cards.map((card) => (
        <div
          key={card.label}
          className={`flex items-center gap-4 rounded-xl p-4 border ${card.bg} ${card.border}`}
        >
          <div className={`w-10 h-10 rounded-xl ${card.iconBg} flex items-center justify-center text-lg flex-shrink-0`}>
            {card.icon}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-gray-500 dark:text-gray-400">{card.label}</p>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className={`text-2xl font-bold ${card.text}`}>{card.value}</span>
              <span className="text-xs text-gray-400 dark:text-gray-500">{card.sub}</span>
            </div>
          </div>
        </div>
      ))}

      {/* Congestion card with progress bar */}
      <div className={`rounded-xl p-4 border ${congestionConfig.bg} ${congestionConfig.border}`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-500/20 flex items-center justify-center text-lg flex-shrink-0">
              🚦
            </div>
            <div>
              <p className="text-xs font-medium text-gray-500 dark:text-gray-400">Congestion</p>
              <p className={`text-xl font-bold ${congestionConfig.text}`}>{congestion}</p>
            </div>
          </div>
          {congestion !== 'N/A' && (
            <span className={`text-xs font-semibold ${congestionConfig.text}`}>{congestionConfig.pct}%</span>
          )}
        </div>
        {congestion !== 'N/A' && (
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mt-1">
            <div
              className={`h-1.5 rounded-full transition-all duration-700 ${congestionConfig.bar}`}
              style={{ width: `${congestionConfig.pct}%` }}
            />
          </div>
        )}
      </div>
    </div>
  );
};
