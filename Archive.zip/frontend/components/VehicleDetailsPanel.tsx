'use client';

import React from 'react';
import { Vehicle } from '@/lib/api';
import { VEHICLE_COLORS } from '@/lib/constants';

interface VehicleDetailsPanelProps {
  vehicle: Vehicle | null;
  speedHistory: number[];
}

function StatBadge({
  label,
  value,
  colorClass,
}: {
  label: string;
  value: string;
  colorClass: string;
}) {
  return (
    <div className={`rounded-xl p-3 border ${colorClass}`}>
      <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{label}</p>
      <p className="text-base font-bold">{value}</p>
    </div>
  );
}

export const VehicleDetailsPanel: React.FC<VehicleDetailsPanelProps> = ({
  vehicle,
  speedHistory,
}) => {
  if (!vehicle) {
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <div className="w-12 h-12 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-2xl">
          🚘
        </div>
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">No vehicle selected</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">Click a vehicle in the list</p>
        </div>
      </div>
    );
  }

  const avgSpeed = speedHistory.length > 0
    ? (speedHistory.reduce((a, b) => a + b, 0) / speedHistory.length).toFixed(1)
    : '—';
  const maxSpeed = speedHistory.length > 0 ? Math.max(...speedHistory).toFixed(1) : '—';
  const minSpeed = speedHistory.length > 0 ? Math.min(...speedHistory).toFixed(1) : '—';
  const dotColor = VEHICLE_COLORS[vehicle.label as keyof typeof VEHICLE_COLORS] || '#6b7280';

  const currentSpeed = vehicle.speed ?? 0;
  const maxPossible = 120;
  const speedPct = Math.min((currentSpeed / maxPossible) * 100, 100);
  const speedBarColor = currentSpeed > 80 ? 'bg-red-500' : currentSpeed > 50 ? 'bg-amber-500' : 'bg-green-500';

  return (
    <div className="space-y-4">
      {/* Vehicle header */}
      <div className="flex items-center gap-3 pb-3 border-b border-gray-100 dark:border-gray-800">
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${dotColor}20`, border: `2px solid ${dotColor}` }}>
          <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: dotColor }} />
        </div>
        <div>
          <p className="font-bold text-gray-900 dark:text-white text-sm">Vehicle #{vehicle.id}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{vehicle.label}</p>
        </div>
      </div>

      {/* Current speed with progress bar */}
      <div className="rounded-xl border border-blue-200 dark:border-blue-500/20 bg-blue-50 dark:bg-blue-500/10 p-4">
        <div className="flex items-baseline justify-between mb-2">
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400">Current Speed</p>
          <p className="text-xs text-gray-400">{maxPossible} km/h max</p>
        </div>
        <p className="text-3xl font-bold text-blue-700 dark:text-blue-400 mb-2">
          {vehicle.speed !== null ? vehicle.speed.toFixed(1) : '—'}
          <span className="text-sm font-normal text-gray-400 ml-1">km/h</span>
        </p>
        <div className="w-full bg-blue-100 dark:bg-blue-500/20 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-700 ${speedBarColor}`}
            style={{ width: `${speedPct}%` }}
          />
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-3 gap-2">
        <StatBadge
          label="Avg"
          value={`${avgSpeed}${avgSpeed !== '—' ? '' : ''}`}
          colorClass="bg-purple-50 dark:bg-purple-500/10 border-purple-200 dark:border-purple-500/20 text-purple-700 dark:text-purple-400"
        />
        <StatBadge
          label="Max"
          value={`${maxSpeed}`}
          colorClass="bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400"
        />
        <StatBadge
          label="Min"
          value={`${minSpeed}`}
          colorClass="bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/20 text-green-700 dark:text-green-400"
        />
      </div>

      {/* Speed history mini-chart */}
      <div className="rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 p-3">
        <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
          Speed History · {speedHistory.length} samples
        </p>
        <div className="flex gap-0.5 h-14 items-end">
          {speedHistory.length === 0 ? (
            <p className="text-xs text-gray-400 w-full text-center self-center">No data yet</p>
          ) : (
            speedHistory.map((spd, idx) => {
              const max = Math.max(...speedHistory, 1);
              const pct = (spd / max) * 100;
              const barColor = spd > 80 ? 'from-red-400 to-red-600' : spd > 50 ? 'from-amber-400 to-amber-600' : 'from-green-400 to-green-600';
              return (
                <div
                  key={idx}
                  className={`flex-1 bg-gradient-to-t ${barColor} rounded-sm opacity-80 hover:opacity-100 transition-opacity`}
                  style={{ height: `${pct}%`, minHeight: '2px' }}
                  title={`${spd.toFixed(1)} km/h`}
                />
              );
            })
          )}
        </div>
      </div>

      <p className="text-xs text-gray-400 dark:text-gray-500 text-center">
        Tap another vehicle to switch
      </p>
    </div>
  );
};
