'use client';

import React, { useMemo } from 'react';
import {
  LineChart, Line,
  BarChart, Bar,
  AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { MetricsSnapshot } from '@/hooks/useMetricsHistory';

interface AnalyticsChartsProps {
  history: MetricsSnapshot[];
  isStreaming: boolean;
}

function ChartCard({ title, icon, children }: { title: string; icon: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 p-4">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-base">{icon}</span>
        <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-200">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function CustomTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 shadow-xl p-2.5 text-xs">
      <p className="text-gray-500 dark:text-gray-400 mb-1">{payload[0].payload.time}</p>
      {payload.map((entry: any, i: number) => (
        <p key={i} style={{ color: entry.color }} className="font-semibold">
          {entry.name}: {typeof entry.value === 'number' ? entry.value.toFixed(2) : entry.value}
        </p>
      ))}
    </div>
  );
}

const AXIS_STYLE = { fontSize: 11, fill: '#9ca3af' };
const GRID_COLOR = 'rgba(156,163,175,0.15)';

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({ history }) => {
  const chartData = useMemo(() =>
    history.map((point) => ({
      time: new Date(point.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      vehicle_count: point.vehicle_count,
      average_speed: point.average_speed,
      congestion_numeric: point.congestion_level === 'High' ? 3 : point.congestion_level === 'Medium' ? 2 : 1,
      congestion_level: point.congestion_level,
    })),
    [history]
  );

  if (history.length === 0) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {['Average Speed Trend', 'Vehicle Count', 'Congestion Level'].map((title) => (
          <div key={title} className="rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 p-6 flex flex-col items-center justify-center gap-3 min-h-40">
            <div className="w-10 h-10 rounded-xl bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xl">📊</div>
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">Start a stream to collect data</p>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3 mb-2">
        {[
          { label: 'Data Points', value: history.length, color: 'blue' },
          { label: 'Peak Speed', value: `${Math.max(...history.map((h) => h.average_speed)).toFixed(1)} km/h`, color: 'green' },
          { label: 'Peak Vehicles', value: Math.max(...history.map((h) => h.vehicle_count)), color: 'purple' },
        ].map((s) => (
          <div key={s.label} className={`rounded-xl p-3 border text-center ${
            s.color === 'blue' ? 'bg-blue-50 dark:bg-blue-500/10 border-blue-200 dark:border-blue-500/20'
              : s.color === 'green' ? 'bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/20'
              : 'bg-purple-50 dark:bg-purple-500/10 border-purple-200 dark:border-purple-500/20'
          }`}>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-0.5">{s.label}</p>
            <p className={`text-xl font-bold ${
              s.color === 'blue' ? 'text-blue-700 dark:text-blue-400'
                : s.color === 'green' ? 'text-green-700 dark:text-green-400'
                : 'text-purple-700 dark:text-purple-400'
            }`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Speed line chart */}
      <ChartCard title="Average Speed Trend" icon="⚡">
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} />
            <XAxis dataKey="time" tick={AXIS_STYLE} stroke={GRID_COLOR} />
            <YAxis tick={AXIS_STYLE} stroke={GRID_COLOR} label={{ value: 'km/h', angle: -90, position: 'insideLeft', style: AXIS_STYLE }} />
            <Tooltip content={<CustomTooltip />} />
            <Line
              type="monotone" dataKey="average_speed" stroke="#3b82f6"
              strokeWidth={2} dot={false} activeDot={{ r: 5, strokeWidth: 0 }}
              name="Avg Speed"
            />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Vehicle count bar chart */}
      <ChartCard title="Vehicle Count Timeline" icon="🚗">
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={chartData} barCategoryGap="30%">
            <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} />
            <XAxis dataKey="time" tick={AXIS_STYLE} stroke={GRID_COLOR} />
            <YAxis tick={AXIS_STYLE} stroke={GRID_COLOR} label={{ value: 'vehicles', angle: -90, position: 'insideLeft', style: AXIS_STYLE }} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="vehicle_count" fill="#8b5cf6" radius={[6, 6, 0, 0]} name="Vehicle Count" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Congestion area chart */}
      <ChartCard title="Congestion Level Timeline" icon="🚦">
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="congestionGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID_COLOR} />
            <XAxis dataKey="time" tick={AXIS_STYLE} stroke={GRID_COLOR} />
            <YAxis
              tick={AXIS_STYLE} stroke={GRID_COLOR}
              domain={[0, 3]} ticks={[1, 2, 3]}
              tickFormatter={(v) => v === 1 ? 'Low' : v === 2 ? 'Med' : 'High'}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                const d = payload[0].payload;
                return (
                  <div className="rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 shadow-xl p-2.5 text-xs">
                    <p className="text-gray-500 dark:text-gray-400 mb-1">{d.time}</p>
                    <p className="font-semibold text-amber-600 dark:text-amber-400">{d.congestion_level}</p>
                  </div>
                );
              }}
            />
            <Area
              type="monotone" dataKey="congestion_numeric" stroke="#f59e0b" strokeWidth={2}
              fillOpacity={1} fill="url(#congestionGrad)" name="Congestion"
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
};
