'use client';

import React from 'react';
import { Vehicle } from '@/lib/api';
import { VEHICLE_COLORS } from '@/lib/constants';

interface VehicleListProps {
  vehicles: Vehicle[];
  selectedVehicle: Vehicle | null;
  onSelectVehicle: (vehicle: Vehicle) => void;
  isStreaming: boolean;
}

function EmptyState({ message, sub }: { message: string; sub: string }) {
  return (
    <div className="flex flex-col items-center gap-2 py-8 text-center">
      <div className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-xl">
        🚗
      </div>
      <div>
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{message}</p>
        <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">{sub}</p>
      </div>
    </div>
  );
}

function speedColor(speed: number | null) {
  if (speed === null) return 'text-gray-400 dark:text-gray-500 bg-gray-100 dark:bg-gray-800';
  if (speed > 80) return 'text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10';
  if (speed > 50) return 'text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10';
  return 'text-green-700 dark:text-green-400 bg-green-50 dark:bg-green-500/10';
}

export const VehicleList: React.FC<VehicleListProps> = ({
  vehicles,
  selectedVehicle,
  onSelectVehicle,
  isStreaming,
}) => {
  if (!isStreaming) {
    return <EmptyState message="No stream active" sub="Start a stream to see vehicles" />;
  }

  if (vehicles.length === 0) {
    return <EmptyState message="No vehicles detected" sub="Waiting for traffic data…" />;
  }

  return (
    <div className="rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
      <div className="overflow-y-auto max-h-72 divide-y divide-gray-100 dark:divide-gray-800">
        {vehicles.map((vehicle) => {
          const isSelected = selectedVehicle?.id === vehicle.id;
          const dotColor = VEHICLE_COLORS[vehicle.label as keyof typeof VEHICLE_COLORS] || '#6b7280';
          const speedCls = speedColor(vehicle.speed);

          return (
            <button
              key={vehicle.id}
              onClick={() => onSelectVehicle(vehicle)}
              className={`w-full px-4 py-3 text-left transition-all duration-150 ${
                isSelected
                  ? 'bg-blue-50 dark:bg-blue-500/10'
                  : 'bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800/60'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: dotColor }}
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">
                      #{vehicle.id}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{vehicle.label}</p>
                  </div>
                </div>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full flex-shrink-0 ${speedCls}`}>
                  {vehicle.speed !== null ? `${vehicle.speed.toFixed(1)} km/h` : '—'}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
