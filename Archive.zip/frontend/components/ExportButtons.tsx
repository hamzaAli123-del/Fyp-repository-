'use client';

import React from 'react';
import { MetricsSnapshot } from '@/hooks/useMetricsHistory';
import { exportAsCSV, exportAsJSON } from '@/lib/export';

interface ExportButtonsProps {
  history: MetricsSnapshot[];
  isStreaming: boolean;
}

export const ExportButtons: React.FC<ExportButtonsProps> = ({ history }) => {
  const handleExportCSV = () => {
    const ts = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    exportAsCSV(history, `traffic-metrics-${ts}.csv`);
  };

  const handleExportJSON = () => {
    const ts = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    exportAsJSON(history, `traffic-metrics-${ts}.json`);
  };

  const hasData = history.length > 0;

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 p-3 flex items-center gap-3">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-lg ${hasData ? 'bg-green-100 dark:bg-green-500/20' : 'bg-gray-200 dark:bg-gray-700'}`}>
          {hasData ? '✅' : '📭'}
        </div>
        <div>
          <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">
            {hasData ? `${history.length} records ready` : 'No data yet'}
          </p>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {hasData ? 'Download as CSV or JSON' : 'Start a stream to collect data'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={handleExportCSV}
          disabled={!hasData}
          className="flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border border-blue-200 dark:border-blue-500/30 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500/20 disabled:opacity-40 disabled:cursor-not-allowed text-blue-700 dark:text-blue-400 font-semibold text-xs transition-all duration-200 group"
        >
          <span className="text-xl group-hover:scale-110 transition-transform">📊</span>
          Export CSV
        </button>
        <button
          onClick={handleExportJSON}
          disabled={!hasData}
          className="flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border border-green-200 dark:border-green-500/30 bg-green-50 dark:bg-green-500/10 hover:bg-green-100 dark:hover:bg-green-500/20 disabled:opacity-40 disabled:cursor-not-allowed text-green-700 dark:text-green-400 font-semibold text-xs transition-all duration-200 group"
        >
          <span className="text-xl group-hover:scale-110 transition-transform">📦</span>
          Export JSON
        </button>
      </div>

      <p className="text-xs text-gray-400 dark:text-gray-500 text-center">
        Filename includes timestamp for easy tracking
      </p>
    </div>
  );
};
