'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Sun, Moon, Menu, X, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Navbar() {
  const [isDark, setIsDark] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Check for dark mode preference
    if (localStorage.getItem('theme') === 'dark') {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }

    // Handle scroll effect
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleDarkMode = () => {
    if (isDark) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDark(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDark(true);
    }
  };

  const navItems = [
    { label: 'Home', href: '/' },
    { label: 'Dashboard', href: '/dashboard' },
    { label: 'About', href: '/about' },
  ];

  return (
    <nav className={`fixed w-full top-0 z-50 transition-all duration-300 ${
      scrolled 
        ? `${isDark ? 'bg-gray-950 shadow-lg shadow-black/50' : 'bg-white shadow-lg shadow-gray-200/50'}` 
        : `${isDark ? 'bg-gray-950/95 backdrop-blur-md' : 'bg-white/95 backdrop-blur-md'}`
    } border-b ${
      isDark 
        ? 'border-gray-800' 
        : 'border-gray-200'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo with Traffic Signal Theme */}
          <Link href="/">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-3 group cursor-pointer hover:scale-105 transition-transform"
            >
              <div className="relative w-12 h-12 flex items-center justify-center">
                {/* Animated Traffic Light */}
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-green-500/20 rounded-full blur-lg group-hover:blur-xl transition-all"></div>
                <div className="flex flex-col gap-1 relative">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-3 h-3 rounded-full bg-red-500 shadow-lg shadow-red-500/60"
                  ></motion.div>
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: 0.67 }}
                    className="w-3 h-3 rounded-full bg-yellow-400 shadow-lg shadow-yellow-400/60"
                  ></motion.div>
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: 1.34 }}
                    className="w-3 h-3 rounded-full bg-green-500 shadow-lg shadow-green-500/60"
                  ></motion.div>
                </div>
              </div>
              <div className="flex flex-col">
                <h1 className="text-2xl font-bold bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 bg-clip-text text-transparent">
                  TrafficMind
                </h1>
                <p className={`text-xs font-medium transition-colors ${
                  isDark ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  Smart Traffic
                </p>
              </div>
            </motion.div>
          </Link>

          {/* Desktop Navigation - CENTERED */}
          <div className="hidden md:flex items-center gap-1 absolute left-1/2 transform -translate-x-1/2">
            {navItems.map((item, index) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
              >
                <Link
                  href={item.href}
                  className={`relative px-4 py-2 rounded-lg font-semibold transition-all duration-300 group flex items-center gap-2 ${
                    isDark
                      ? 'text-white hover:text-white hover:bg-gradient-to-r hover:from-red-500/20 hover:to-green-500/20'
                      : 'text-gray-900 hover:text-gray-900 hover:bg-gray-200/70'
                  }`}
                >
                  <span>{item.label}</span>
                  
                  {/* Animated underline */}
                  <span className="absolute bottom-0 left-4 right-4 h-1 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></span>
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Right Side - Dark Mode Toggle & Menu */}
          <div className="flex items-center gap-4 flex-shrink-0">
            {/* Dark Mode Toggle */}
            <motion.button
              whileHover={{ scale: 1.1, rotate: 20 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleDarkMode}
              className={`relative w-12 h-12 rounded-full transition-colors flex items-center justify-center ${
                isDark 
                  ? 'bg-gray-800 hover:bg-gray-700' 
                  : 'bg-gray-100 hover:bg-gray-200'
              }`}
              aria-label="Toggle dark mode"
            >
              {mounted && (
                <>
                  {isDark ? (
                    <Sun className="w-5 h-5 text-yellow-400" />
                  ) : (
                    <Moon className="w-5 h-5 text-blue-600" />
                  )}
                </>
              )}
            </motion.button>

            {/* Mobile Menu Button */}
            <button
              className={`md:hidden w-10 h-10 rounded-lg transition-colors flex items-center justify-center ${
                isDark
                  ? 'bg-gray-800 hover:bg-gray-700 text-white'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
              }`}
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
            >
              {isOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`md:hidden py-4 border-t transition-all ${
              isDark 
                ? 'border-gray-800 bg-gray-900' 
                : 'border-gray-200 bg-gray-50'
            }`}
          >
            <div className="flex flex-col gap-2">
              {navItems.map((item) => (
                <motion.div
                  key={item.label}
                  whileHover={{ x: 8 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 10 }}
                >
                  <Link
                    href={item.href}
                    className={`px-4 py-3 rounded-lg flex items-center gap-3 font-semibold transition-all ${
                      isDark
                        ? 'text-white hover:text-white hover:bg-gradient-to-r hover:from-red-500/20 hover:to-green-500/20'
                        : 'text-gray-900 hover:text-gray-900 hover:bg-gray-200/70'
                    }`}
                    onClick={() => setIsOpen(false)}
                  >
                    {item.label}
                  </Link>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </nav>
  );
}
