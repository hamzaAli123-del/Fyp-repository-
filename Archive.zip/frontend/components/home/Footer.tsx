'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { GraduationCap, MapPin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const links = [
    { label: 'Dashboard', href: '/dashboard' },
    { label: 'Features', href: '/#features' },
    { label: 'About', href: '/about' },
  ];

  return (
    <footer className="bg-gray-100 dark:bg-gray-900 text-gray-600 dark:text-gray-400 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-10 mb-10">

          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex-shrink-0"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="flex flex-col gap-1">
                <div className="w-3 h-3 rounded-full bg-red-500 shadow-lg shadow-red-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-400 shadow-lg shadow-yellow-400/50"></div>
                <div className="w-3 h-3 rounded-full bg-green-500 shadow-lg shadow-green-500/50"></div>
              </div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 bg-clip-text text-transparent">
                TrafficMind
              </h3>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 max-w-xs">
              Intelligent traffic management system for modern cities.
            </p>
          </motion.div>

          {/* Nav Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex flex-col gap-2"
          >
            <h4 className="text-gray-900 dark:text-white font-bold mb-1 text-sm uppercase tracking-widest">
              Quick Links
            </h4>
            <div className="flex flex-row gap-6">
              {links.map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="text-sm hover:text-gray-900 dark:hover:text-white transition-colors duration-300"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </motion.div>

          {/* University */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col gap-3"
          >
            <h4 className="text-gray-900 dark:text-white font-bold text-sm uppercase tracking-widest">
              Final Year Project
            </h4>
            <div className="flex items-start gap-2 text-sm">
              <GraduationCap className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
              <span>University of Agriculture, Faisalabad</span>
            </div>
            <div className="flex items-start gap-2 text-sm">
              <MapPin className="w-4 h-4 mt-0.5 text-red-500 flex-shrink-0" />
              <span>Faisalabad, Pakistan</span>
            </div>
          </motion.div>

        </div>

        {/* Divider */}
        <div className="border-t border-gray-300 dark:border-gray-700 mb-6"></div>

        {/* Bottom */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row items-center justify-between gap-2 text-sm text-gray-500 dark:text-gray-400"
        >
          <p>&copy; {currentYear} TrafficMind. All rights reserved.</p>
          <p className="text-xs">
            Built as a Final Year Project &mdash; University of Agriculture, Faisalabad
          </p>
        </motion.div>

      </div>
    </footer>
  );
}