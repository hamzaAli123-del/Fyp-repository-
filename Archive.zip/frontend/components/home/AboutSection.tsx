'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Users, Target, Award } from 'lucide-react';

export default function AboutSection() {
  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 transition-colors duration-300">
      {/* Project Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-white to-gray-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 transition-colors duration-300">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={containerVariants}
            className="text-center mb-16"
          >
            <h2 className="mt-16 text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              TrafficMind: Intelligent{' '}
              <span className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 bg-clip-text text-transparent">
                Traffic Management
              </span>{' '}
              System
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              A cutting-edge AI-powered solution designed to revolutionize urban traffic management through real-time vehicle detection, intelligent congestion analysis, and predictive analytics.
            </p>
          </motion.div>

          {/* Project Details Grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {/* Problem & Solution */}
            <motion.div
              initial="hidden"
              whileInView="visible"
              variants={containerVariants}
              className="group"
            >
              <div className="h-full p-8 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 hover:border-red-500/50 dark:hover:border-red-500/50 transition-all duration-300 shadow-lg hover:shadow-xl">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 rounded-lg bg-gradient-to-br from-red-500/20 to-red-500/10 dark:from-red-500/30 dark:to-red-500/10">
                    <Target className="w-6 h-6 text-red-500" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Problem & Vision</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Urban traffic congestion leads to wasted time, increased pollution, and economic losses. Traditional traffic management systems are reactive and inefficient.
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  TrafficMind leverages advanced computer vision and AI to provide real-time insights, enabling traffic authorities to make data-driven decisions and optimize traffic flow proactively.
                </p>
              </div>
            </motion.div>

            {/* Key Features */}
            <motion.div
              initial="hidden"
              whileInView="visible"
              variants={containerVariants}
              transition={{ delay: 0.1 }}
              className="group"
            >
              <div className="h-full p-8 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 hover:border-green-500/50 dark:hover:border-green-500/50 transition-all duration-300 shadow-lg hover:shadow-xl">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 rounded-lg bg-gradient-to-br from-green-500/20 to-green-500/10 dark:from-green-500/30 dark:to-green-500/10">
                    <Zap className="w-6 h-6 text-green-500" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Core Technology</h3>
                </div>
                <ul className="space-y-3 text-gray-600 dark:text-gray-400">
                  <li className="flex items-start gap-3">
                    <span className="text-green-500 font-bold mt-1">•</span>
                    <span><strong>YOLOv8 Detection:</strong> Real-time vehicle detection with 95%+ accuracy</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-yellow-500 font-bold mt-1">•</span>
                    <span><strong>Vehicle Tracking:</strong> Continuous monitoring across camera feeds</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-red-500 font-bold mt-1">•</span>
                    <span><strong>Speed Analysis:</strong> Real-time speed calculation and detection</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-blue-500 font-bold mt-1">•</span>
                    <span><strong>Congestion Analytics:</strong> Intelligent traffic flow analysis</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>

          {/* Tech Stack */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={containerVariants}
            transition={{ delay: 0.2 }}
            className="p-8 rounded-xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 dark:from-purple-500/20 dark:to-pink-500/20 border border-purple-500/20 dark:border-purple-500/30"
          >
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Technology Stack</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Backend</h4>
                <p className="text-gray-600 dark:text-gray-400">Python, FastAPI, YOLOv8, OpenCV, PostgreSQL</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Frontend</h4>
                <p className="text-gray-600 dark:text-gray-400">Next.js 15, React 19, TypeScript, Tailwind CSS</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Infrastructure</h4>
                <p className="text-gray-600 dark:text-gray-400">RTMP Streaming, WebSocket, Cloud Deployment</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Student Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-100 via-white to-gray-100 dark:from-gray-900 dark:via-gray-950 dark:to-black transition-colors duration-300">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={containerVariants}
            className="text-center mb-16"
          >
            <div className="inline-block mb-4">
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 dark:bg-amber-500/20 border border-amber-500/20">
                <Award className="w-4 h-4 text-amber-500" />
                <span className="text-sm font-semibold text-amber-600 dark:text-amber-400">Final Year Project</span>
              </div>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Meet the{' '}
              <span className="bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-400 bg-clip-text text-transparent">
                Developer
              </span>
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Innovative vision and technical expertise behind TrafficMind
            </p>
          </motion.div>

          {/* Student Profile Card */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={containerVariants}
            transition={{ delay: 0.1 }}
            className="max-w-2xl mx-auto"
          >
            <div className="group relative rounded-2xl overflow-hidden">
              {/* Animated Border */}
              <div className="absolute inset-0 bg-gradient-to-r from-amber-500 via-yellow-500 to-orange-500 p-[2px] rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute inset-0 bg-white dark:bg-black rounded-2xl"></div>
              </div>

              {/* Card Content */}
              <div className="relative p-8 md:p-12 rounded-2xl bg-white dark:bg-gradient-to-br dark:from-gray-900 dark:to-black border border-gray-200 dark:border-gray-800 group-hover:border-transparent transition-all duration-300 shadow-lg">
                <div className="flex flex-col items-center text-center">
                  {/* Avatar */}
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    className="mb-6"
                  >
                    <div className="w-32 h-32 rounded-full bg-gradient-to-br from-amber-500 via-yellow-500 to-orange-500 p-1">
                      <div className="w-full h-full rounded-full bg-white dark:bg-black flex items-center justify-center">
                        <Users className="w-16 h-16 text-amber-500" />
                      </div>
                    </div>
                  </motion.div>

                  {/* Name and Title */}
                  <h3 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-2">Hamza Ali</h3>
                  <p className="text-amber-600 dark:text-amber-400 font-semibold text-lg mb-6">Final Year Project Developer</p>

                  {/* Bio */}
                  <p className="text-gray-700 dark:text-gray-300 mb-8 leading-relaxed max-w-xl">
                    A passionate computer science student with a keen interest in artificial intelligence, computer vision, and full-stack development. Dedicated to solving real-world problems through innovative technology and creating impactful solutions for smart city management.
                  </p>

                  {/* Skills */}
                  <div className="mb-8">
                    <h4 className="text-gray-900 dark:text-white font-semibold mb-4">Key Expertise</h4>
                    <div className="flex flex-wrap gap-3 justify-center">
                      {['AI & ML', 'Computer Vision', 'Python', 'Full-Stack Dev', 'System Design', 'Data Analytics'].map((skill) => (
                        <motion.div
                          key={skill}
                          whileHover={{ scale: 1.05 }}
                          className="px-4 py-2 rounded-full bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 text-gray-800 dark:text-white text-sm font-medium"
                        >
                          {skill}
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Acknowledgments */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            variants={containerVariants}
            transition={{ delay: 0.2 }}
            className="mt-16 p-8 rounded-xl bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 text-center"
          >
            <h4 className="text-gray-900 dark:text-white font-semibold mb-2">Built with Dedication and Innovation</h4>
            <p className="text-gray-600 dark:text-gray-400">
              This project represents months of research, development, and optimization to create a production-ready smart traffic management solution.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
