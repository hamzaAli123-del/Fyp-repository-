// import React, { useRef, useEffect } from 'react';
// import { Canvas, useFrame } from '@react-three/fiber';
// import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
// import * as THREE from 'three';

// // Simple Vehicle Component
// function Vehicle({ position, color }: { position: [number, number, number]; color: string }) {
//   const meshRef = useRef<THREE.Mesh>(null);

//   useFrame(() => {
//     if (meshRef.current) {
//       meshRef.current.position.z += 0.02;
//       if (meshRef.current.position.z > 20) {
//         meshRef.current.position.z = -20;
//       }
//     }
//   });

//   return (
//     <mesh ref={meshRef} position={position}>
//       <boxGeometry args={[0.8, 0.4, 1.2]} />
//       <meshStandardMaterial color={color} metalness={0.7} roughness={0.2} />
//     </mesh>
//   );
// }

// // Traffic Light Component
// function TrafficLight({ position, state }: { position: [number, number, number]; state: 'red' | 'yellow' | 'green' }) {
//   const colors = {
//     red: '#ff0000',
//     yellow: '#ffff00',
//     green: '#00ff00',
//   };

//   return (
//     <group position={position}>
//       <mesh position={[0, 1.5, 0]}>
//         <cylinderGeometry args={[0.3, 0.3, 3, 8]} />
//         <meshStandardMaterial color="#333333" />
//       </mesh>

//       {/* Red Light */}
//       <mesh position={[0, 1.8, 0.31]}>
//         <sphereGeometry args={[0.25, 8, 8]} />
//         <meshStandardMaterial color={state === 'red' ? '#ff0000' : '#330000'} emissive={state === 'red' ? '#ff0000' : '#000000'} />
//       </mesh>

//       {/* Yellow Light */}
//       <mesh position={[0, 0.8, 0.31]}>
//         <sphereGeometry args={[0.25, 8, 8]} />
//         <meshStandardMaterial color={state === 'yellow' ? '#ffff00' : '#333300'} emissive={state === 'yellow' ? '#ffff00' : '#000000'} />
//       </mesh>

//       {/* Green Light */}
//       <mesh position={[0, -0.2, 0.31]}>
//         <sphereGeometry args={[0.25, 8, 8]} />
//         <meshStandardMaterial color={state === 'green' ? '#00ff00' : '#003300'} emissive={state === 'green' ? '#00ff00' : '#000000'} />
//       </mesh>
//     </group>
//   );
// }

// // Road Component
// function Road() {
//   return (
//     <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
//       <planeGeometry args={[30, 40]} />
//       <meshStandardMaterial color="#444444" />
//     </mesh>
//   );
// }

// // Road Markings
// function RoadMarkings() {
//   const lines = [];
//   for (let i = -20; i < 20; i++) {
//     lines.push(
//       <mesh key={i} position={[0, 0.01, i]} rotation={[-Math.PI / 2, 0, 0]}>
//         <planeGeometry args={[15, 0.3]} />
//         <meshStandardMaterial color="#ffff00" />
//       </mesh>
//     );
//   }
//   return <group>{lines}</group>;
// }

// // Main 3D Scene
// function TrafficScene() {
//   const [trafficState, setTrafficState] = React.useState<'red' | 'yellow' | 'green'>('green');

//   React.useEffect(() => {
//     const interval = setInterval(() => {
//       setTrafficState((prev) => {
//         if (prev === 'green') return 'yellow';
//         if (prev === 'yellow') return 'red';
//         return 'green';
//       });
//     }, 3000);
//     return () => clearInterval(interval);
//   }, []);

//   return (
//     <>
//       <PerspectiveCamera makeDefault position={[0, 8, 15]} />
//       <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={2} />

//       {/* Lighting */}
//       <ambientLight intensity={0.8} />
//       <directionalLight position={[10, 10, 5]} intensity={1} />

//       {/* Road */}
//       <Road />
//       <RoadMarkings />

//       {/* Traffic Lights */}
//       <TrafficLight position={[-8, 0, -15]} state={trafficState} />
//       <TrafficLight position={[8, 0, -15]} state={trafficState} />

//       {/* Vehicles */}
//       <Vehicle position={[-3, 0.2, -5]} color="#e74c3c" />
//       <Vehicle position={[0, 0.2, 0]} color="#3498db" />
//       <Vehicle position={[3, 0.2, 5]} color="#2ecc71" />
//       <Vehicle position={[-5, 0.2, 10]} color="#f39c12" />
//     </>
//   );
// }

// // Wrapper Component
// export default function HeroScene() {
//   return (
//     <div className="w-full h-full">
//       <Canvas>
//         <TrafficScene />
//       </Canvas>
//     </div>
//   );
// }

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';

// 🚗 Realistic Car Component
function Car({
  position,
  color,
  speed,
  lane,
}: {
  position: [number, number, number];
  color: string;
  speed: number;
  lane: number;
}) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (groupRef.current) {
      groupRef.current.position.z += speed;
      if (groupRef.current.position.z > 22) {
        groupRef.current.position.z = -22;
      }
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Car Body - lower */}
      <mesh position={[0, 0.2, 0]}>
        <boxGeometry args={[1.1, 0.35, 2.2]} />
        <meshStandardMaterial color={color} metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Car Roof / Cabin */}
      <mesh position={[0, 0.52, 0.1]}>
        <boxGeometry args={[0.85, 0.32, 1.2]} />
        <meshStandardMaterial color={color} metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Windshield Front */}
      <mesh position={[0, 0.48, 0.72]} rotation={[0.35, 0, 0]}>
        <boxGeometry args={[0.78, 0.28, 0.05]} />
        <meshStandardMaterial color="#aaddff" transparent opacity={0.6} metalness={0.1} roughness={0} />
      </mesh>

      {/* Windshield Rear */}
      <mesh position={[0, 0.48, -0.55]} rotation={[-0.35, 0, 0]}>
        <boxGeometry args={[0.78, 0.28, 0.05]} />
        <meshStandardMaterial color="#aaddff" transparent opacity={0.6} metalness={0.1} roughness={0} />
      </mesh>

      {/* Wheels */}
      {[[-0.55, -0.05, 0.7], [0.55, -0.05, 0.7], [-0.55, -0.05, -0.7], [0.55, -0.05, -0.7]].map(
        ([x, y, z], i) => (
          <mesh key={i} position={[x, y, z]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.22, 0.22, 0.15, 16]} />
            <meshStandardMaterial color="#111111" metalness={0.3} roughness={0.9} />
          </mesh>
        )
      )}

      {/* Wheel Rims */}
      {[[-0.56, -0.05, 0.7], [0.56, -0.05, 0.7], [-0.56, -0.05, -0.7], [0.56, -0.05, -0.7]].map(
        ([x, y, z], i) => (
          <mesh key={i} position={[x, y, z]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.12, 0.12, 0.16, 8]} />
            <meshStandardMaterial color="#cccccc" metalness={0.9} roughness={0.1} />
          </mesh>
        )
      )}

      {/* Headlights */}
      <mesh position={[-0.3, 0.2, 1.12]}>
        <boxGeometry args={[0.2, 0.1, 0.05]} />
        <meshStandardMaterial color="#ffffaa" emissive="#ffff88" emissiveIntensity={1.5} />
      </mesh>
      <mesh position={[0.3, 0.2, 1.12]}>
        <boxGeometry args={[0.2, 0.1, 0.05]} />
        <meshStandardMaterial color="#ffffaa" emissive="#ffff88" emissiveIntensity={1.5} />
      </mesh>

      {/* Tail Lights */}
      <mesh position={[-0.3, 0.2, -1.12]}>
        <boxGeometry args={[0.2, 0.1, 0.05]} />
        <meshStandardMaterial color="#ff2200" emissive="#ff0000" emissiveIntensity={1} />
      </mesh>
      <mesh position={[0.3, 0.2, -1.12]}>
        <boxGeometry args={[0.2, 0.1, 0.05]} />
        <meshStandardMaterial color="#ff2200" emissive="#ff0000" emissiveIntensity={1} />
      </mesh>
    </group>
  );
}

// 🚦 Traffic Signal Component
function TrafficLight({ position, state }: { position: [number, number, number]; state: 'red' | 'yellow' | 'green' }) {
  return (
    <group position={position}>
      {/* Pole */}
      <mesh position={[0, 1.5, 0]}>
        <cylinderGeometry args={[0.07, 0.09, 4, 12]} />
        <meshStandardMaterial color="#555555" metalness={0.6} roughness={0.4} />
      </mesh>

      {/* Signal Box */}
      <mesh position={[0, 3.4, 0]}>
        <boxGeometry args={[0.55, 1.4, 0.45]} />
        <meshStandardMaterial color="#222222" metalness={0.5} roughness={0.5} />
      </mesh>

      {/* Red */}
      <mesh position={[0, 3.95, 0.24]}>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial
          color={state === 'red' ? '#ff2200' : '#330000'}
          emissive={state === 'red' ? '#ff2200' : '#000000'}
          emissiveIntensity={state === 'red' ? 2 : 0}
        />
      </mesh>

      {/* Yellow */}
      <mesh position={[0, 3.4, 0.24]}>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial
          color={state === 'yellow' ? '#ffdd00' : '#332200'}
          emissive={state === 'yellow' ? '#ffdd00' : '#000000'}
          emissiveIntensity={state === 'yellow' ? 2 : 0}
        />
      </mesh>

      {/* Green */}
      <mesh position={[0, 2.85, 0.24]}>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial
          color={state === 'green' ? '#00ff44' : '#003300'}
          emissive={state === 'green' ? '#00ff44' : '#000000'}
          emissiveIntensity={state === 'green' ? 2 : 0}
        />
      </mesh>

      {/* Arm extending over road */}
      <mesh position={[1.2, 4.1, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.05, 0.05, 2.4, 8]} />
        <meshStandardMaterial color="#555555" metalness={0.6} roughness={0.4} />
      </mesh>
    </group>
  );
}

// 🛣️ Road with Lanes
function Road() {
  return (
    <group>
      {/* Main road surface */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[14, 50]} />
        <meshStandardMaterial color="#2a2a2a" roughness={0.95} />
      </mesh>

      {/* Sidewalks */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[-8.5, 0.01, 0]}>
        <planeGeometry args={[3, 50]} />
        <meshStandardMaterial color="#888888" roughness={0.9} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[8.5, 0.01, 0]}>
        <planeGeometry args={[3, 50]} />
        <meshStandardMaterial color="#888888" roughness={0.9} />
      </mesh>

      {/* Curbs */}
      <mesh position={[-7, 0.05, 0]}>
        <boxGeometry args={[0.2, 0.1, 50]} />
        <meshStandardMaterial color="#aaaaaa" />
      </mesh>
      <mesh position={[7, 0.05, 0]}>
        <boxGeometry args={[0.2, 0.1, 50]} />
        <meshStandardMaterial color="#aaaaaa" />
      </mesh>
    </group>
  );
}

// Lane Dashes
function LaneMarkings() {
  const dashes = [];
  for (let z = -24; z < 24; z += 3) {
    // Center double yellow line
    dashes.push(
      <mesh key={`c1-${z}`} position={[-0.15, 0.015, z]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.1, 1.8]} />
        <meshStandardMaterial color="#ffdd00" />
      </mesh>
    );
    dashes.push(
      <mesh key={`c2-${z}`} position={[0.15, 0.015, z]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.1, 1.8]} />
        <meshStandardMaterial color="#ffdd00" />
      </mesh>
    );

    // Lane dividers left side
    dashes.push(
      <mesh key={`l-${z}`} position={[-3.5, 0.015, z]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.1, 1.8]} />
        <meshStandardMaterial color="#ffffff" />
      </mesh>
    );

    // Lane dividers right side
    dashes.push(
      <mesh key={`r-${z}`} position={[3.5, 0.015, z]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.1, 1.8]} />
        <meshStandardMaterial color="#ffffff" />
      </mesh>
    );
  }
  return <group>{dashes}</group>;
}

// Simple Building
function Building({ position, height, color }: { position: [number, number, number]; height: number; color: string }) {
  return (
    <group position={position}>
      <mesh position={[0, height / 2, 0]}>
        <boxGeometry args={[2.5, height, 2.5]} />
        <meshStandardMaterial color={color} metalness={0.3} roughness={0.7} />
      </mesh>
      {/* Windows rows */}
      {Array.from({ length: Math.floor(height / 1.5) }).map((_, i) => (
        <mesh key={i} position={[1.26, 0.8 + i * 1.5, 0]}>
          <boxGeometry args={[0.05, 0.5, 1.5]} />
          <meshStandardMaterial color="#aaddff" emissive="#aaddff" emissiveIntensity={0.3} transparent opacity={0.7} />
        </mesh>
      ))}
    </group>
  );
}

// Full Scene
function TrafficScene() {
  const [trafficState, setTrafficState] = React.useState<'red' | 'yellow' | 'green'>('green');

  React.useEffect(() => {
    const cycle: ('red' | 'yellow' | 'green')[] = ['green', 'yellow', 'red'];
    let i = 0;
    const interval = setInterval(() => {
      i = (i + 1) % 3;
      setTrafficState(cycle[i]);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 10, 18]} />
      <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.6} maxPolarAngle={Math.PI / 2.2} />

      {/* Lighting */}
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 15, 10]} intensity={1.2} castShadow />
      <pointLight position={[0, 8, 0]} intensity={0.4} color="#ffffff" />
      {/* Signal glow lights */}
      <pointLight
        position={[-7, 4, -8]}
        intensity={trafficState === 'red' ? 1.5 : 0}
        color="#ff2200"
        distance={5}
      />
      <pointLight
        position={[-7, 4, -8]}
        intensity={trafficState === 'green' ? 1.5 : 0}
        color="#00ff44"
        distance={5}
      />

      {/* Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]}>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial color="#1a3a1a" roughness={1} />
      </mesh>

      {/* Road */}
      <Road />
      <LaneMarkings />

      {/* Traffic Lights */}
      <TrafficLight position={[-7.5, 0, -8]} state={trafficState} />
      <TrafficLight position={[7.5, 0, -8]} state={trafficState} />

      {/* Cars - left lanes (going forward) */}
      <Car position={[-5, 0, -10]} color="#e74c3c" speed={0.06} lane={-5} />
      <Car position={[-1.8, 0, -2]} color="#3498db" speed={0.05} lane={-1.8} />
      <Car position={[-5, 0, 8]} color="#9b59b6" speed={0.07} lane={-5} />

      {/* Cars - right lanes (going backward) */}
      <Car position={[1.8, 0, 5]} color="#f39c12" speed={-0.055} lane={1.8} />
      <Car position={[5, 0, -3]} color="#1abc9c" speed={-0.065} lane={5} />
      <Car position={[1.8, 0, 15]} color="#e67e22" speed={-0.05} lane={1.8} />

      {/* Buildings left */}
      <Building position={[-12, 0, -10]} height={8} color="#5d6d7e" />
      <Building position={[-12, 0, -3]} height={12} color="#4a4a6a" />
      <Building position={[-12, 0, 6]} height={6} color="#6d5d4e" />
      <Building position={[-15, 0, 0]} height={10} color="#3d5a3e" />

      {/* Buildings right */}
      <Building position={[12, 0, -10]} height={10} color="#5d4e6d" />
      <Building position={[12, 0, -3]} height={7} color="#4e5d6d" />
      <Building position={[12, 0, 6]} height={14} color="#6d6d4e" />
      <Building position={[15, 0, 0]} height={9} color="#4a3d5d" />
    </>
  );
}

export default function HeroScene() {
  return (
    <div className="w-full h-full">
      <Canvas shadows>
        <TrafficScene />
      </Canvas>
    </div>
  );
}