'use client';

import React, { Suspense } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import Navbar from '@/components/home/Navbar';
import FeaturesSection from '@/components/home/FeaturesSection';
import CTASection from '@/components/home/CTASection';
import Footer from '@/components/home/Footer';
import { ArrowRight, Play } from 'lucide-react';

// Dynamically import the 3D scene to avoid SSR issues
const HeroScene = dynamic(() => import('@/components/home/HeroScene'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-screen bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 mb-4">
          <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-400 animate-pulse" style={{ animationDelay: '0.1s' }}></div>
          <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
        </div>
        <p className="text-gray-300 font-medium">Loading 3D Scene...</p>
      </div>
    </div>
  ),
});

export default function Home() {
  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {/* Navbar */}
      <Navbar />

      {/* Hero Section with 3D Background */}
      <section className="relative w-full min-h-screen pt-20">
        {/* 3D Scene Background */}
        <div className="absolute inset-0 top-20">
          <Suspense fallback={<div className="w-full h-full bg-gradient-to-br from-gray-900 to-black" />}>
            <HeroScene />
          </Suspense>
        </div>

        {/* Overlay & Content */}
        <div className="absolute inset-0 top-20 bg-gradient-to-b from-black/40 via-black/20 to-transparent"></div>

        {/* Hero Content */}
        <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-80px)] px-4">
          <div className="text-center">

            {/* Main Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="mt-8 can text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight"
            >
              The Future of <br />
              <span className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 bg-clip-text text-transparent">
                Traffic Management
              </span>
            </motion.h1>

            {/* Subheading */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto mb-12"
            >
              Real-time vehicle tracking, AI-powered congestion detection, and intelligent traffic optimization for modern cities.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12"
            >
              <Link href="/dashboard">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 text-white font-bold rounded-lg hover:shadow-2xl shadow-lg transition-all duration-300 flex items-center gap-2 group text-lg"
                >
                  Launch Dashboard
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </motion.button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <FeaturesSection />

      {/* CTA Section */}
      <CTASection />

      {/* Divider */}
      <hr className="border-t border-gray-300 dark:border-gray-700"/>

      {/* Footer */}
      <Footer />
    </div>
  );
}
