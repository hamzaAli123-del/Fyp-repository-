'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Activity, BarChart3, AlertCircle, Zap, Eye, TrendingUp } from 'lucide-react';

const features = [
  {
    icon: Activity,
    title: 'Real-Time Tracking',
    description: 'Monitor vehicle movements in real-time with advanced detection algorithms and instant updates.',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: BarChart3,
    title: 'Advanced Analytics',
    description: 'Comprehensive traffic analysis with detailed metrics, historical data, and predictive insights.',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: AlertCircle,
    title: 'Congestion Detection',
    description: 'Intelligent congestion detection and alerts to manage traffic flow efficiently.',
    color: 'from-red-500 to-orange-500',
  },
  {
    icon: Zap,
    title: 'High Performance',
    description: 'Lightning-fast processing with optimized algorithms for instant insights and decisions.',
    color: 'from-yellow-500 to-amber-500',
  },
  {
    icon: Eye,
    title: 'Live Video Feed',
    description: 'Stream live video feeds from multiple traffic cameras for comprehensive coverage.',
    color: 'from-green-500 to-emerald-500',
  },
  {
    icon: TrendingUp,
    title: 'Predictive Analytics',
    description: 'Machine learning-powered predictions to anticipate traffic patterns and congestion.',
    color: 'from-indigo-500 to-blue-500',
  },
];

export default function FeaturesSection() {
  return (
    <section id='features' className="py-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-gray-950 transition-colors duration-300">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Powerful Features for <span className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 bg-clip-text text-transparent">Smart Traffic</span> Management
          </h2>
          <p className="text-lg text-gray-700 dark:text-gray-200 max-w-2xl mx-auto">
            Our comprehensive traffic management system provides everything you need to optimize traffic flow and reduce congestion.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="group relative bg-gray-50 dark:bg-gray-900 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-200 dark:border-gray-800 overflow-hidden"
              >
                {/* Gradient Background */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-15 transition-opacity duration-300`}></div>

                {/* Icon */}
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 10 }}
                  className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 shadow-lg`}
                >
                  <Icon className="w-7 h-7 text-white" />
                </motion.div>

                {/* Content */}
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{feature.title}</h3>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{feature.description}</p>

                {/* Border Effect */}
                <div className="absolute inset-0 rounded-2xl border border-transparent group-hover:border-gray-300 dark:group-hover:border-gray-600 transition-all duration-300 pointer-events-none"></div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
