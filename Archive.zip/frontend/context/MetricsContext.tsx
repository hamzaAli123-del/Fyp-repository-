'use client';

import React, { createContext, useContext, useState, useCallback } from 'react';
import { Metrics, Vehicle } from '@/lib/api';

export interface PersistentVehicle extends Vehicle {
  firstSeen: number;
  lastSeen: number;
  totalDetections: number;
  averageSpeed: number;
  maxSpeed: number;
  minSpeed: number;
  isCurrentlyDetected: boolean;
  speeds: number[];
}

interface MetricsContextType {
  metrics: Metrics | null;
  updateMetrics: (metrics: Metrics) => void;
  isStreaming: boolean;
  setIsStreaming: (value: boolean) => void;
  streamUrl: string;
  setStreamUrl: (url: string) => void;
  // Persistent vehicle data
  vehicleRegistry: Map<number, PersistentVehicle>;
  updatePersistentVehicles: (vehicles: Vehicle[]) => void;
  getAllVehicles: () => PersistentVehicle[];
  getVehicleById: (id: number) => PersistentVehicle | null;
  getCurrentlyDetectedVehicles: () => PersistentVehicle[];
  clearVehicleRegistry: () => void;
  getSessionStats: () => {
    totalVehicles: number;
    currentlyDetected: number;
    averageSpeed: number;
    totalDetections: number;
  };
}

const MetricsContext = createContext<MetricsContextType | undefined>(undefined);

export const MetricsProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamUrl, setStreamUrl] = useState('');
  const [vehicleRegistry, setVehicleRegistry] = useState<Map<number, PersistentVehicle>>(new Map());

  const updateMetrics = useCallback((newMetrics: Metrics) => {
    setMetrics(newMetrics);
  }, []);

  const updatePersistentVehicles = useCallback((vehicles: Vehicle[]) => {
    const now = Date.now();

    setVehicleRegistry((prevRegistry) => {
      const newRegistry = new Map(prevRegistry);

      // Mark all vehicles as not currently detected
      newRegistry.forEach((vehicle) => {
        vehicle.isCurrentlyDetected = false;
        vehicle.lastSeen = now;
      });

      // Update or create vehicles from current detection
      vehicles.forEach((vehicle) => {
        const existing = newRegistry.get(vehicle.id);

        if (existing) {
          // Update existing vehicle
          const speeds = [...existing.speeds];
          if (vehicle.speed !== null && vehicle.speed > 0) {
            speeds.push(vehicle.speed);
            // Keep only last 100 samples
            if (speeds.length > 100) {
              speeds.shift();
            }
          }

          const validSpeeds = speeds.filter(s => s > 0);
          const avgSpeed = validSpeeds.length > 0
            ? validSpeeds.reduce((a, b) => a + b, 0) / validSpeeds.length
            : 0;
          const maxSpeed = validSpeeds.length > 0 ? Math.max(...validSpeeds) : 0;
          const minSpeed = validSpeeds.length > 0 ? Math.min(...validSpeeds) : 0;

          newRegistry.set(vehicle.id, {
            ...existing,
            ...vehicle,
            lastSeen: now,
            totalDetections: existing.totalDetections + 1,
            averageSpeed: Math.round(avgSpeed * 10) / 10,
            maxSpeed: Math.round(maxSpeed * 10) / 10,
            minSpeed: Math.round(minSpeed * 10) / 10,
            isCurrentlyDetected: true,
            speeds,
          });
        } else {
          // Create new vehicle
          const speeds = vehicle.speed !== null && vehicle.speed > 0 ? [vehicle.speed] : [];

          newRegistry.set(vehicle.id, {
            ...vehicle,
            firstSeen: now,
            lastSeen: now,
            totalDetections: 1,
            averageSpeed: vehicle.speed || 0,
            maxSpeed: vehicle.speed || 0,
            minSpeed: vehicle.speed || 0,
            isCurrentlyDetected: true,
            speeds,
          });
        }
      });

      return newRegistry;
    });
  }, []);

  const getAllVehicles = useCallback(() => {
    return Array.from(vehicleRegistry.values()).sort((a, b) => b.lastSeen - a.lastSeen);
  }, [vehicleRegistry]);

  const getVehicleById = useCallback((id: number) => {
    return vehicleRegistry.get(id) || null;
  }, [vehicleRegistry]);

  const getCurrentlyDetectedVehicles = useCallback(() => {
    return Array.from(vehicleRegistry.values())
      .filter(v => v.isCurrentlyDetected)
      .sort((a, b) => a.id - b.id);
  }, [vehicleRegistry]);

  const clearVehicleRegistry = useCallback(() => {
    setVehicleRegistry(new Map());
  }, []);

  const getSessionStats = useCallback(() => {
    const allVehicles = Array.from(vehicleRegistry.values());
    const totalVehicles = allVehicles.length;
    const currentlyDetected = allVehicles.filter(v => v.isCurrentlyDetected).length;

    const allSpeeds = allVehicles
      .flatMap(v => v.speeds)
      .filter(s => s > 0);

    const avgSpeed = allSpeeds.length > 0
      ? allSpeeds.reduce((a, b) => a + b, 0) / allSpeeds.length
      : 0;

    return {
      totalVehicles,
      currentlyDetected,
      averageSpeed: Math.round(avgSpeed * 10) / 10,
      totalDetections: allVehicles.reduce((sum, v) => sum + v.totalDetections, 0),
    };
  }, [vehicleRegistry]);

  return (
    <MetricsContext.Provider
      value={{
        metrics,
        updateMetrics,
        isStreaming,
        setIsStreaming,
        streamUrl,
        setStreamUrl,
        vehicleRegistry,
        updatePersistentVehicles,
        getAllVehicles,
        getVehicleById,
        getCurrentlyDetectedVehicles,
        clearVehicleRegistry,
        getSessionStats,
      }}
    >
      {children}
    </MetricsContext.Provider>
  );
};

export const useMetrics = () => {
  const context = useContext(MetricsContext);
  if (!context) {
    throw new Error('useMetrics must be used within MetricsProvider');
  }
  return context;
};
