import math
import numpy as np
from scipy.optimize import linear_sum_assignment


def compute_iou(bbox1, bbox2):
    x1 = max(bbox1[0], bbox2[0])
    y1 = max(bbox1[1], bbox2[1])
    x2 = min(bbox1[2], bbox2[2])
    y2 = min(bbox1[3], bbox2[3])
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    if intersection == 0:
        return 0.0
    area1 = (bbox1[2] - bbox1[0]) * (bbox1[3] - bbox1[1])
    area2 = (bbox2[2] - bbox2[0]) * (bbox2[3] - bbox2[1])
    union = area1 + area2 - intersection
    return intersection / union if union > 0 else 0.0


class Track:
    def __init__(self, track_id, detection):
        self.id = track_id
        self.bbox = detection['bbox']
        self.label = detection['label']
        self.confidence = detection['confidence']
        self.centroid = self._get_centroid(detection['bbox'])
        self.missed_frames = 0

    def update(self, detection):
        self.bbox = detection['bbox']
        self.label = detection['label']
        self.confidence = detection['confidence']
        self.centroid = self._get_centroid(detection['bbox'])
        self.missed_frames = 0

    def mark_missed(self):
        self.missed_frames += 1

    def _get_centroid(self, bbox):
        x1, y1, x2, y2 = bbox
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    def to_dict(self):
        return {
            'id': self.id,
            'bbox': self.bbox,
            'label': self.label,
            'centroid': self.centroid,
            'confidence': self.confidence,
        }


class VehicleTracker:
    def __init__(self, max_age=5, min_iou=0.3):
        self.next_id = 1
        self.tracks = {}
        self.max_age = max_age
        self.min_iou = min_iou

    def update(self, detections):
        if not detections:
            for track in self.tracks.values():
                track.mark_missed()
            self._remove_dead_tracks()
            return [t.to_dict() for t in self.tracks.values()]

        track_ids = list(self.tracks.keys())
        track_list = [self.tracks[tid] for tid in track_ids]

        if not track_list:
            for det in detections:
                self._create_track(det)
            return [t.to_dict() for t in self.tracks.values()]

        iou_matrix = np.zeros((len(detections), len(track_list)))
        for d_idx, det in enumerate(detections):
            for t_idx, track in enumerate(track_list):
                iou_matrix[d_idx][t_idx] = compute_iou(det['bbox'], track.bbox)

        det_indices, track_indices = linear_sum_assignment(-iou_matrix)

        matched_dets = set()
        matched_tracks = set()

        for d_idx, t_idx in zip(det_indices, track_indices):
            if iou_matrix[d_idx][t_idx] >= self.min_iou:
                track_id = track_ids[t_idx]
                self.tracks[track_id].update(detections[d_idx])
                matched_dets.add(d_idx)
                matched_tracks.add(t_idx)

        for d_idx, det in enumerate(detections):
            if d_idx not in matched_dets:
                self._create_track(det)

        for t_idx, track in enumerate(track_list):
            if t_idx not in matched_tracks:
                track.mark_missed()

        self._remove_dead_tracks()
        return [t.to_dict() for t in self.tracks.values()]

    def _create_track(self, detection):
        self.tracks[self.next_id] = Track(self.next_id, detection)
        self.next_id += 1

    def _remove_dead_tracks(self):
        to_remove = [tid for tid, t in self.tracks.items() if t.missed_frames > self.max_age]
        for tid in to_remove:
            del self.tracks[tid]