from collections import deque


class CongestionAnalyzer:
    # HCM-inspired thresholds
    _LEVELS = [
        ('Critical', lambda c, s: c > 15 and s < 10),
        ('High',     lambda c, s: c > 10 and s < 20),
        ('Medium',   lambda c, s: c > 5  and s < 40),
        ('Low',      lambda c, s: True),
    ]

    def __init__(self, frame_width: int = 640, frame_height: int = 480, history_len: int = 30):
        self.frame_area = frame_width * frame_height
        self._history: deque = deque(maxlen=history_len)

    def analyze(self, vehicle_count, speeds):
        """
        Analyze traffic metrics based on vehicle count and speed data.

        Args:
            vehicle_count: Number of vehicles detected in current frame
            speeds: List of speed values (km/h) for all vehicles

        Returns:
            Dictionary with vehicle_count, average_speed, congestion_level,
            density, and trend.
        """
        avg_speed = round(sum(speeds) / len(speeds), 1) if speeds else 0.0

        level = 'Low'
        for name, predicate in self._LEVELS:
            if predicate(vehicle_count, avg_speed):
                level = name
                break

        # Vehicles per million pixels of frame area
        density = round(vehicle_count / self._frame_area_mpx, 2)

        result = {
            'vehicle_count': vehicle_count,
            'average_speed': avg_speed,
            'congestion_level': level,
            'density': density,
        }

        self._history.append(level)
        result['trend'] = self._compute_trend()
        return result

    @property
    def _frame_area_mpx(self):
        return self.frame_area / 1_000_000

    def _compute_trend(self):
        """Return 'improving', 'worsening', or 'stable' based on recent history."""
        order = {'Low': 0, 'Medium': 1, 'High': 2, 'Critical': 3}
        if len(self._history) < 2:
            return 'stable'
        first_half = list(self._history)[:len(self._history) // 2]
        second_half = list(self._history)[len(self._history) // 2:]
        avg_first = sum(order[l] for l in first_half) / len(first_half)
        avg_second = sum(order[l] for l in second_half) / len(second_half)
        if avg_second > avg_first + 0.2:
            return 'worsening'
        if avg_second < avg_first - 0.2:
            return 'improving'
        return 'stable'