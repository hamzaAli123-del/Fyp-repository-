import logging

import cv2
import numpy as np
import torch
from ultralytics import YOLO

logger = logging.getLogger(__name__)

YOLO_CLASS_NAMES = {2: 'car', 7: 'truck', 5: 'bus', 3: 'motorcycle'}
VEHICLE_CLASS_IDS = list(YOLO_CLASS_NAMES.keys())


def _select_device() -> str:
    if torch.cuda.is_available():
        return 'cuda'
    if torch.backends.mps.is_available():
        return 'mps'
    return 'cpu'


class VehicleDetector:
    def __init__(self, model_path: str = 'yolov8n.pt', conf: float = 0.4, iou: float = 0.45):
        self.conf = conf
        self.iou = iou
        self.device = _select_device()
        self.model = YOLO(model_path)
        logger.info("YOLOv8 model loaded on device=%s conf=%.2f iou=%.2f", self.device, conf, iou)

    def detect(self, frame):
        results = self.model(
            frame,
            verbose=False,
            conf=self.conf,
            iou=self.iou,
            classes=VEHICLE_CLASS_IDS,
            device=self.device,
        )[0]

        detections = []
        for box in results.boxes:
            class_id = int(box.cls[0])
            label = YOLO_CLASS_NAMES.get(class_id)
            if label is None:
                continue

            x1, y1, x2, y2 = map(int, box.xyxy[0])
            confidence = float(box.conf[0])

            detections.append({
                'bbox': (x1, y1, x2, y2),
                'confidence': round(confidence, 2),
                'label': label,
            })

        return detections