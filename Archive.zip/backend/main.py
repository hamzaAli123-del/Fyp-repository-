import cv2
import logging
import threading
import time
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from detection import VehicleDetector
from tracking import VehicleTracker
from speed import SpeedEstimator
from congestion import CongestionAnalyzer

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)

app = FastAPI(title="Traffic Management System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

detector = VehicleDetector()
tracker = VehicleTracker()
speed_estimator = SpeedEstimator()
congestion_analyzer = CongestionAnalyzer()

latest_frame = None
latest_metrics = {
    "vehicle_count": 0,
    "average_speed": 0.0,
    "congestion_level": "Low",
    "vehicles": []
}
stream_running = False
capture_thread = None

class StreamRequest(BaseModel):
    stream_url: str

def process_stream(stream_url):
    global latest_frame, latest_metrics, stream_running

    try:
        cap = cv2.VideoCapture(stream_url)

        if not cap.isOpened():
            logger.warning("Could not open stream URL %s, falling back to camera 0", stream_url)
            cap = cv2.VideoCapture(0)

        fps = cap.get(cv2.CAP_PROP_FPS)
        if fps and fps > 0:
            speed_estimator.set_fps(fps)
            logger.info("Video FPS detected: %.2f", fps)

        frame_count = 0

        while stream_running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.1)
                continue

            frame_count += 1
            if frame_count % 2 != 0:
                continue

            frame = cv2.resize(frame, (640, 480))

            detections = detector.detect(frame)
            tracked = tracker.update(detections)
            speeds_dict = speed_estimator.update(tracked)

            line_y1, line_y2 = speed_estimator.get_line_positions()
            cv2.line(frame, (0, line_y1), (640, line_y1), (0, 255, 255), 2)
            cv2.line(frame, (0, line_y2), (640, line_y2), (0, 255, 0), 2)

            vehicles_data = []
            speed_values = []

            for obj in tracked:
                obj_id = obj['id']
                x1, y1, x2, y2 = obj['bbox']
                label = obj['label']
                speed = speeds_dict.get(obj_id, 0.0)

                speed_values.append(speed)

                if speed is not None and speed > 0:
                    display = f"ID:{obj_id} {label} {speed}km/h"
                else:
                    display = f"ID:{obj_id} {label}"

                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, display, (x1, y1 - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                vehicles_data.append({
                    "id": obj_id,
                    "label": label,
                    "speed": speed if speed > 0 else 0.0
                })

            metrics = congestion_analyzer.analyze(len(tracked), speed_values)
            metrics["vehicles"] = vehicles_data

            latest_frame = frame.copy()
            latest_metrics = metrics

        cap.release()

    except Exception as e:
        logger.exception("Fatal error in process_stream: %s", e)
        stream_running = False

def generate_frames():
    global latest_frame
    while stream_running:
        if latest_frame is not None:
            ret, buffer = cv2.imencode('.jpg', latest_frame)
            if ret:
                frame_bytes = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        time.sleep(0.033)


@app.get("/")
def home():
    return {"message": "Traffic Management System API is running"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/start-stream")
def start_stream(request: StreamRequest):
    global stream_running, capture_thread
    if stream_running:
        return {"message": "Stream already running"}
    stream_running = True
    capture_thread = threading.Thread(
        target=process_stream,
        args=(request.stream_url,),
        daemon=True
    )
    capture_thread.start()
    return {"message": "Stream started"}

@app.post("/stop-stream")
def stop_stream():
    global stream_running
    stream_running = False
    return {"message": "Stream stopped"}

@app.get("/metrics")
def get_metrics():
    return latest_metrics

@app.get("/video-feed")
def video_feed():
    return StreamingResponse(
        generate_frames(),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )