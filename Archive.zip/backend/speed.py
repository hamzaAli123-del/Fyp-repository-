import time
import math

LINE_Y1 = 200
LINE_Y2 = 400
REAL_DISTANCE_METERS = 10

# Pixels per meter calibration - adjust based on your camera setup
PIXELS_PER_METER = 50

class SpeedEstimator:
    def __init__(self, fps=30):
        self.fps = fps
        self.frame_time = 1.0 / fps
        self.previous_centroids = {}
        self.speeds = {}
        self.speed_history = {}
        self.line1_times = {}
        self.line2_times = {}

    def set_fps(self, fps: float):
        """Update FPS from actual video capture properties."""
        self.fps = fps
        self.frame_time = 1.0 / fps

    def _calculate_distance(self, c1, c2):
        """Calculate Euclidean distance between two points"""
        return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

    def _weighted_average(self, history):
        """Weighted moving average; most-recent readings have higher weight."""
        n = len(history)
        weights = list(range(1, n + 1))
        return sum(w * v for w, v in zip(weights, history)) / sum(weights)

    def _cleanup(self, current_ids):
        """Remove all per-object state for IDs no longer being tracked."""
        stale = set(self.speed_history.keys()) - current_ids
        for obj_id in stale:
            self.speed_history.pop(obj_id, None)
            self.speeds.pop(obj_id, None)
            self.previous_centroids.pop(obj_id, None)
            self.line1_times.pop(obj_id, None)
            self.line2_times.pop(obj_id, None)

    def update(self, tracked_objects):
        """
        Calculate speed based on frame-to-frame centroid movement.
        """
        current_time = time.time()
        current_centroids = {}

        for obj in tracked_objects:
            obj_id = obj['id']
            x1, y1, x2, y2 = obj['bbox']
            centroid = ((x1 + x2) // 2, (y1 + y2) // 2)
            current_centroids[obj_id] = centroid

            if obj_id in self.previous_centroids:
                prev_centroid = self.previous_centroids[obj_id]
                pixel_distance = self._calculate_distance(centroid, prev_centroid)
                real_distance_m = pixel_distance / PIXELS_PER_METER
                speed_ms = real_distance_m / self.frame_time
                speed_kmh = speed_ms * 3.6

                if pixel_distance > 2:
                    if obj_id not in self.speed_history:
                        self.speed_history[obj_id] = []

                    self.speed_history[obj_id].append(speed_kmh)

                    if len(self.speed_history[obj_id]) > 10:
                        self.speed_history[obj_id].pop(0)

                    self.speeds[obj_id] = round(self._weighted_average(self.speed_history[obj_id]), 1)
                else:
                    if obj_id not in self.speeds:
                        self.speeds[obj_id] = 0.0
            else:
                if obj_id not in self.speeds:
                    self.speeds[obj_id] = 0.0

            cy = (y1 + y2) // 2
            if abs(cy - LINE_Y1) < 15:
                if obj_id not in self.line1_times:
                    self.line1_times[obj_id] = current_time

            if abs(cy - LINE_Y2) < 15:
                if obj_id not in self.line2_times:
                    self.line2_times[obj_id] = current_time

            if obj_id in self.line1_times and obj_id in self.line2_times:
                time_diff = abs(self.line2_times[obj_id] - self.line1_times[obj_id])
                if time_diff > 0:
                    speed_ms = REAL_DISTANCE_METERS / time_diff
                    speed_kmh = round(speed_ms * 3.6, 1)
                    if speed_kmh > 0:
                        self.speeds[obj_id] = speed_kmh

        self.previous_centroids = current_centroids

        current_ids = set(obj['id'] for obj in tracked_objects)
        self._cleanup(current_ids)

        return self.speeds

    def get_speed(self, obj_id):
        return self.speeds.get(obj_id, None)

    def get_line_positions(self):
        return LINE_Y1, LINE_Y2